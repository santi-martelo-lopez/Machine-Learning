import os
import colorama
#
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
#
import torch as T
import torch.nn as nn # for the observation we will use linear layers, not convolutional layers
import torch.nn.functional as F # for defineing activation functions
import torch.optim as optim # for suing Adam optimizer
import pickle
#
#
np.random.seed(32)
#numpy printing options
np.set_printoptions(precision=2)
#numpy.set_printoptions(suppress=True)
#
#
def pr_bar(progress,total, color = colorama.Fore.YELLOW):
    barLen = 80
    percentage = barLen * progress/float(total) # total may be an integer
    bar = '*'*int(percentage) +'-'*(barLen-int(percentage))
    print(color+f"\r|{bar}| {percentage/float(barLen)*100:.2f}%",end="\r")
#
#
def plot_learning_curve_ap(x,scores,epsilons,fileName,lines=None,window=20):
    # for all plicy -> ap
    fig = plt.figure()
    ax = fig.add_subplot(111, label="1")
    ax2 = fig.add_subplot(111, label="2", frame_on=False)
    #
    ax.plot(x,epsilons,color="C0")
    ax.set_xlabel("Training Episodes",color="C0")
    ax.set_ylabel("Epsilon",color="C0")
    ax.tick_params(axis='x',colors="C0")
    ax.tick_params(axis='y',colors="C0")
    #
    N = len(scores)
    running_avg = np.empty(N)
    for t in range(N):
        running_avg[t] = np.mean(scores[max(0,t-window):(t+1)])
        #running_avg[t] = np.mean(scores[max(0,t-window):max(window+1,t+1)])
    #
    ax2.scatter(x,running_avg,color="C1")
    ax2.get_xaxis().set_visible(False)
    ax2.yaxis.tick_right()
    ax2.set_ylabel('Avegare Score',color="C1")
    ax2.yaxis.set_label_position('right')
    ax2.tick_params(axis='y',colors="C1")
    plt.savefig(fileName)
    #plt.show()
#
#
def plot_learning_curve_averageScore(x,scores,fileName):
    # for all plicy -> ap
    fig = plt.figure()
    ax = fig.add_subplot(111, label="1")
    #
    ax.scatter(x,scores,color="C1")
    ax.set_xlabel("Training Episodes",color="C1")
    ax.yaxis.tick_right()
    ax.set_ylabel('Avegare Score',color="C1")
    ax.yaxis.set_label_position('right')
    ax.tick_params(axis='y',colors="C1")
    plt.savefig(fileName)
    #plt.show()
#
#
#
#
def plot_learning_curve_totalScore_steps(x,scores,n_steps,fileName,lines=None,window=20):
    # for all plicy -> ap
    fig = plt.figure()
    ax = fig.add_subplot(111, label="1")
    ax2 = fig.add_subplot(111, label="2", frame_on=False)
    #
    ax.plot(x,n_steps,color="C0")
    ax.set_xlabel("Training Episodes",color="C0")
    ax.set_ylabel("Transition Sptes",color="C0")
    ax.tick_params(axis='x',colors="C0")
    ax.tick_params(axis='y',colors="C0")
    #
    #
    ax2.scatter(x,scores,color="C1")
    ax2.get_xaxis().set_visible(False)
    ax2.yaxis.tick_right()
    ax2.set_ylabel('Total Score',color="C1")
    ax2.yaxis.set_label_position('right')
    ax2.tick_params(axis='y',colors="C1")
    plt.savefig(fileName)
    #plt.show()
#
#
#
#
class sea_environment(object):
    def __init__(self,leftBoundary=-25,rightBoundary=25,frontBoundary=0,backBoundary=40,offset=0.5,lpp=2,
                                                                                    time_policy = -0.1,
                                                                                    success_policy = 1000,
                                                                                    fail_policy = -1000,
                                                                                    distance_policy = 0.2,
                                                                                    target_radius = 0.5,
                                                                                    max_steps = 1000 ):
        self.leftBoundary       = leftBoundary
        self.rightBoundary      = rightBoundary
        self.backBoundary       = backBoundary
        self.frontBoundary      = frontBoundary
        self.XrangeTarget       = np.arange(leftBoundary+2*offset,rightBoundary-2*offset,0.2)
        self.YrangeTarget       = np.arange(backBoundary-12*offset,backBoundary-2*offset,0.2)
        self.XrangeBoat         = np.arange(leftBoundary+6*offset,rightBoundary-6*offset,0.2)
        self.YrangeBoat         = np.arange(frontBoundary+2*offset,frontBoundary+12*offset,0.2)
        a                       = [leftBoundary,frontBoundary]
        b                       = [leftBoundary,backBoundary]
        c                       = [rightBoundary,backBoundary]
        d                       = [rightBoundary,frontBoundary]
        self.boundary           = np.transpose(np.array([a,b,c,d,a]))
        self.offset             = offset #[m]
        a                       = [leftBoundary+offset,frontBoundary+offset]
        b                       = [leftBoundary+offset,backBoundary-offset]
        c                       = [rightBoundary-offset,backBoundary-offset]
        d                       = [rightBoundary-offset,frontBoundary+offset]
        self.marginalBoundary   = np.transpose(np.array([a,b,c,d,a]))
        #
        self.lpp                = lpp # [m] boat lenght between perpendiculars
        self.time_policy        = time_policy
        self.success_policy     = success_policy 
        self.fail_policy        = fail_policy 
        self.distance_policy    = distance_policy # factor for the traveled distace reward
        self.target_radius      = target_radius # if the bosat reaches the way-point within radius of [targetRadius]m, the boat successed in reachin its destination
        self.max_steps           = max_steps
        #
        _ = self.reset()
    #
    #
    def reset(self,xe =23 , ye=38.0,xs=-20,ys=5):    #check123 use random initialzation
        # wind direction 
        self.windDiection       = 235 #[degrees]
        self.waterDensity       = 1000 # [m^3/kg]
        self.rudderAngle        = 0 #[degrees]
        self.sailAngle          = 0 #[degrees]
        self.maxRudderAngle     = 45
        self.rudderResolution   = self.maxRudderAngle/10
        self.rudderAngleDelta   = 0
        self.sail2windAngle     = 0 # sail angle of attack #[degrees]
        self.boat2windAngle     = 0 # boat angle of attack #[degrees]
        self.rudderArea         = 0.5 # [m^2]
        self.rudderLenght       = self.lpp/2*0.5
        self.sailArea           = 2.0 # [m^2]
        self.rudderProjectedArea= 0 # [m^2]
        self.sailProjectedArea  = 0 # [m^2]
        self.maxYawSpeed        = 30 # [º/s]
        self.maxBoaSpeed        = 10*3600/1856 # [kt]
        self.maxVxSpeed         = 10*3600/1856 # [m/s]
        self.maxVySpeed         = self.maxVxSpeed # [m/s]
        #
        self.boatYaw            = np.random.randint(-45,45) # yaw angle #[degrees]        
        self.boatRoll           = 0 # heel angle #[degrees]
        self.boatHeading        = np.array(np.sin(self.boatYaw*np.pi/180),np.cos(self.boatYaw*np.pi/180)) #[degrees]
        #self.boatHeading[0]     = np.cos(self.boatYaw*np.pi/180)
        #self.boatHeading[1]     = np.cos(self.boatYaw*np.pi/180)
        self.rollSpeed          = 0 # roll angular velocity #[degrees/s]
        self.yawSpeed           = 0 # roll angular velocity #[degrees/s]
        self.rollAcceleration   = 0 # [Degrees/s^2]
        self.yawAcceleration    = 0 # [Degrees/s^2]
        #
        # wayPointLoacation
        xe=np.random.choice(self.XrangeTarget,1)[0]
        ye=np.random.choice(self.YrangeTarget,1)[0]
        xs=np.random.choice(self.XrangeBoat,1)[0]
        ys=np.random.choice(self.YrangeBoat,1)[0]
        #np.random.randint(100)
        self.wayPoint           = np.array([xe,ye]) # destination point
        self.startingPoint      = np.array([xs,ys]) # starting point
        # initial state: location, speeds, acceleration
        self.targetX            = self.wayPoint[0]
        self.targetY            = self.wayPoint[1]
        self.boatX              = self.startingPoint[0] # current OX boat location [m]
        self.boatY              = self.startingPoint[1] # current OY boat location [m]
        self.initialDistance    = self.computeDistance()
        self.distance2taget     = self.initialDistance
        self.windSpeed          = 7 # wind speed [m/s]
        self.boatSpeed          = 0.5 # boat speed [m/s]
        self.boatvx             = np.sin(self.boatYaw*np.pi/180)*self.boatSpeed # OX boat speed [m/s]
        self.boatvy             = np.cos(self.boatYaw*np.pi/180)*self.boatSpeed # OY boat speed [m/s]
        self.boatAcceleration   = 0 # [m/s^2]
        self.boatax             = np.sin(self.boatYaw*np.pi/180)*self.boatAcceleration # OX boat speed [m/s]
        self.boatay             = np.cos(self.boatYaw*np.pi/180)*self.boatAcceleration # OY boat speed [m/s]
        #
        # done_flag
        self.deltaTime          = 1 # [s]
        self.timeResolution     = 1000 # for time integration loop
        self.timeStep           = self.deltaTime/self.timeResolution
        self.reward             = 0
        self.done_flag          = False
        self.observation        = np.array([self.boatX,self.boatY,
                                            self.boatvx,self.boatvy,
                                            self.boatYaw,self.yawSpeed,self.rudderAngle,self.targetX,self.targetY,self.distance2taget],dtype=np.float32) #observation space
        self.sizeObservation    = len(self.observation)
        return self.observation, self.reward, self.done_flag
    #
    #
    def plot_environment(self,epIndex,setpIndex,score,savingPath="")->None:
        plt.figure(figsize=(25,15))
        #
        #plt.gca().set_axis_off()
        plt.subplots_adjust(top = 3, bottom = 2, right = 3, left = 2, 
            hspace = 1, wspace = 1)
        plt.margins(0,0)
        #plt.gca().xaxis.set_major_locator(plt.NullLocator())
        #plt.gca().yaxis.set_major_locator(plt.NullLocator())
        #
        plt.plot(self.wayPoint[0],self.wayPoint[1],'go',markersize = 30)
        plt.plot(self.startingPoint[0],self.startingPoint[1],'bx',markersize = 20)
        #
        plt.plot(self.boundary[0,:],self.boundary[1,:],color='black',linestyle='solid')
        plt.plot(self.marginalBoundary[0,:],self.marginalBoundary[1,:],color='red',linestyle='dashed')
        #
        a = np.cos((360-self.boatYaw)*np.pi/180)
        b = -np.sin((360-self.boatYaw)*np.pi/180)
        c = np.sin((360-self.boatYaw)*np.pi/180)
        d = np.cos((360-self.boatYaw)*np.pi/180)
        rot_poligon101 = np.array([ [ a, b], [c, d] ]) # 2drotation matrix
        #print(f"poligon rotation matrix {rot_poligon101}")
        lpp = self.lpp
        foreBeam = lpp/3
        aftBeam = lpp/5
        #a = [0,-lpp/2]
        #b = [0,-lpp/2*1.5]
        #rudder101 = np.transpose(np.array([a,b]))
        #a = np.cos((360-self.rudderAngle)*np.pi/180)
        #b = -np.sin((360-self.rudderAngle)*np.pi/180)
        #c = np.sin((360-self.rudderAngle)*np.pi/180)
        #d = np.cos((360-self.rudderAngle)*np.pi/180)
        #rot_rudder101 = np.array([ [ a, b], [c, d] ]) # 2drotation matrix
        #rudder101 = np.matmul(rot_rudder101,rudder101[:,:])
        a = [0,lpp-lpp/2]
        b = [foreBeam/2,lpp*0.6-lpp/2]
        c = [aftBeam/2,0-lpp/2]
        f = [0,0-lpp/2]
        temp1 = np.sin((self.rudderAngle)*np.pi/180)
        temp2 = np.cos((self.rudderAngle)*np.pi/180)
        g = [lpp/2*0.5*temp1,-lpp/2 - lpp/2*0.5*temp2]
        d = [-aftBeam/2,0-lpp/2]
        e = [-foreBeam/2,lpp*0.6-lpp/2]
        poligon101 = np.transpose(np.array([a,b,c,f,g,f,d,e,a])) #poligon101 = np.transpose(np.array([a,b,c,d,e,a]))
        #print(f"poligon101: {poligon101}")
        poligon101 = np.matmul(rot_poligon101,poligon101[:,:])
        #print(f"poligon101: {poligon101}")
        poligon101[0,:] = poligon101[0,:]+self.boatX
        poligon101[1,:] = poligon101[1,:]+self.boatY
        plt.plot(poligon101[0,:],poligon101[1,:],'b',linestyle='solid')
        ax1 = plt.subplot(111) 
        ax1.annotate(f"Boat: [{self.boatX:.2f},{self.boatY:.2f}][m],{self.boatYaw:.2f}[º], \
                     \nSpeed: [{self.boatvx:.2f},{self.boatvy:.2f}][m/s], \
                     \nRudder: {self.rudderAngle:.2f} [º], Delta Rudder: {self.rudderAngleDelta}[º]\
                     \nYaw Speed: {self.yawSpeed:.2f}[º/s], \
                     \nYaw Acceleration: {self.yawAcceleration:.2f}[º/s^2], \
                     \nReward: {self.reward:.2f},score:{score:.2f},\
                     \nDistance: {self.distance2taget:.2f} [m]",  
                    xy =(poligon101[0,0],poligon101[1,0]), xycoords ='data', 
                    xytext =(poligon101[0,1]+lpp*1, poligon101[1,1]-lpp*2), textcoords ='data', 
                #arrowprops=dict(arrowstyle="fancy", color='green'),
                color='blue',size=20)
        """
        a = np.cos((360-self.rudderAngle)*np.pi/180)
        b = -np.sin((360-self.rudderAngle)*np.pi/180)
        c = np.sin((360-self.rudderAngle)*np.pi/180)
        d = np.cos((360-self.rudderAngle)*np.pi/180)
        """
        #a = self.boatLocation
        #b = self.boatLocation+lpp*self.boatHeading
        #c = (a+b)/2
        #windArror101 = np.transpose(np.array([a,b]))
        a = np.cos((360-self.windDiection)*np.pi/180)
        b = -np.sin((360-self.windDiection)*np.pi/180)
        c = np.sin((360-self.windDiection)*np.pi/180)
        d = np.cos((360-self.windDiection)*np.pi/180)
        rot = np.array([ [ a, b], [c, d] ]) # 2drotation matrix
        #print(f"wind rotation matrix {rot}")
        a = [0,-lpp/2]
        b = [0,+lpp/2]
        c = [lpp/5,0]
        d = [-lpp/5,0]
        windArror101 = np.transpose(np.array([a,b,c,d,b]))
        #print(f"windArror101: {windArror101}")
        windArror101 = np.matmul(rot,windArror101[:,:])
        #print(f"windArror101: {windArror101}")
        windArror101[0,:] = windArror101[0,:]+self.boatX+lpp
        windArror101[1,:] = windArror101[1,:]+self.boatY+lpp
        #print(f"windArror101: {windArror101}")
        plt.plot(windArror101[0,:],windArror101[1,:],'g',linestyle='solid')
        ax2 = plt.subplot(111) 
        ax2.annotate(f"Wind: {self.windDiection}[º],{self.windSpeed}[m/s]", 
                    xy =(windArror101[0,0]+lpp,windArror101[1,0]+lpp), xycoords ='data', 
                    xytext =(windArror101[0,1]+lpp, windArror101[1,1]+lpp), textcoords ='data', 
                #arrowprops=dict(arrowstyle="fancy", color='green'),
                color='green',size=20)
        plt.title(f"RL in a Sailing Boat (episode: {epIndex}, step:{setpIndex})")
        #plt.savefig(f'resetFrame_{epIndex}_{setpIndex}.png')
        if len(savingPath)>1:
            reward = str(f"{self.reward:.2f}").replace('-','minus').replace('.','_')
            if setpIndex < 10 :
                setpIndex = f"00{setpIndex}"
            elif setpIndex < 100:
                setpIndex = f"0{setpIndex}"
            plt.savefig(f'{savingPath}/Frame_{epIndex}_{setpIndex}.png', bbox_inches = 'tight',pad_inches = 0)
            #plt.savefig(f'{savingPath}/Frame_{epIndex}_{setpIndex}_{reward}.png', bbox_inches = 'tight',pad_inches = 0)
        plt.close()
    #
    def computeDynamics(self)->None:
        # use lookUp Table
        #
        #   ...
        tt                           = self.timeStep
        #if (np.abs(self.rudderAngle) < 0.5) and (np.abs(self.yawSpeed) > 0):
        if (np.abs(self.rudderAngle) < 0.5):
            self.yawAcceleration     = 0 #self.boatAcceleration/self.rudderProjectedArea*self.rudderAngle #check123
        else:
            self.rudderProjectedArea = self.rudderArea*np.sin(self.rudderAngle*np.pi/180)
            self.yawAcceleration     = 30000*self.boatSpeed*self.rudderProjectedArea/self.waterDensity #self.boatAcceleration/self.rudderProjectedArea*self.rudderAngle #check123
        #
        for timeIndex in range(self.timeResolution):        # time integration loop
            self.boatYaw            += self.yawSpeed*tt + 0.5*self.yawAcceleration*tt**2 #check123
            self.boatYaw             = self.boatYaw if self.boatYaw < 360 else self.boatYaw - 360
            self.boatYaw             = self.boatYaw if self.boatYaw > 0 else 360 - self.boatYaw
            self.yawSpeed           +=  2.5*self.lpp/2*self.yawAcceleration*tt - 0.001*self.yawSpeed #check123
            #self.yawSpeed            = self.yawSpeed if self.yawSpeed < self.maxYawSpeed else self.maxYawSpeed
            #self.yawSpeed            = self.yawSpeed if self.yawSpeed > -self.maxYawSpeed else -self.maxYawSpeed
            #
            self.boatAcceleration    = 0 # + 0.5*self.airDensity*self.sailProjectedArea*self.windSpeed**2 #[kt] check123
            self.boatHeading         = np.array([np.sin(self.boatYaw*np.pi/180),np.cos(self.boatYaw*np.pi/180)])
            self.boatX              += self.boatvx*tt + 0.5*self.boatax*tt**2 #check123 we need to pass cartesian components
            self.boatY              += self.boatvy*tt + 0.5*self.boatay*tt**2 #check123 we need to pass cartesian components
            self.boatvx              = self.boatSpeed*np.sin(self.boatYaw*np.pi/180) + self.boatax*tt #[kt] check123
            self.boatvy              = self.boatSpeed*np.cos(self.boatYaw*np.pi/180) + self.boatay*tt #[kt] check123
            self.boatvx              = self.boatvx if self.boatvx < self.maxVxSpeed else self.maxVxSpeed
            self.boatvx              = self.boatvx if self.boatvx > -self.maxVxSpeed else -self.maxVxSpeed
            self.boatvy              = self.boatvy if self.boatvy < self.maxVySpeed else self.maxVySpeed
            self.boatvy              = self.boatvy if self.boatvy > -self.maxVySpeed else -self.maxVySpeed
            self.boatSpeed           = np.sqrt(self.boatvx**2+self.boatvy**2) 
    #
    #
    def computeDistance(self):
        return np.sqrt( (self.boatX-self.targetX)**2 + (self.boatY-self.targetY)**2 )
    #
    #
    def get_InitialObservation(self):
        self.observation         = np.array([self.boatX,self.boatY,
                                             self.boatvx,self.boatvy,
                                             self.boatYaw,self.yawSpeed,self.rudderAngle,self.targetX,self.targetY,self.distance2taget],dtype=np.float32) 
        return self.observation
    #
    #
    def get_observation(self,action_space,n_steps):
        ## action_spcae = [moveRudder_30_portSide,moveRudder_30_starboardSide]
        #if (action_space.shape[0]>1):
        #    self.action_space = action_space
        #    self.agentChoice  = np.argmax(self.action_space)
        #else:
        #    self.agentChoice  = action_space
        self.agentChoice  = action_space
        match self.agentChoice:
            case 0:
                self.rudderAngleDelta = -self.rudderResolution
            case 1:
                self.rudderAngleDelta = 0
            case 2:
                self.rudderAngleDelta = +self.rudderResolution
            case _:
                print("No action was choosen")
            #
        # action_space = [delta_rudderAngle]
        #delta_rudderAngle   = action_space
        #
        # updating rudder angle 
        self.rudderAngle        += self.rudderAngleDelta
        self.rudderAngle         = self.rudderAngle if self.rudderAngle < self.maxRudderAngle else self.maxRudderAngle
        self.rudderAngle         = self.rudderAngle if self.rudderAngle > -self.maxRudderAngle else -self.maxRudderAngle
        self.rudderAngleDelta    = 0 if np.abs(self.rudderAngle) == self.maxRudderAngle else self.rudderAngleDelta
        #
        # computing distance reward
        oldDistance              = self.distance2taget
        self.computeDynamics()
        self.distance2taget      = self.computeDistance()
        self.travelRatio         = (oldDistance - self.distance2taget)/self.initialDistance*100 #check123
        self.proximityBonus      = np.abs(self.initialDistance - self.distance2taget)/self.initialDistance #check123
        #self.reward              = self.travelRatio*self.distance_policy*self.proximityBonus + self.time_policy #check123        
        #self.reward              = self.travelRatio*self.distance_policy + n_steps*self.time_policy #check123
        #self.reward              = self.travelRatio*self.distance_policy
        self.reward              = self.travelRatio*self.distance_policy*(1+self.proximityBonus)
        #self.reward              = self.travelRatio*self.distance_policy + self.time_policy #check123
        #
        # checking if the sailing jouney can continue
        #if self.distance2taget/self.initialDistance < 0.01:
        if self.distance2taget < self.target_radius:
            self.done_flag      = True 
            self.reward        += self.success_policy
        elif self.boatX < self.leftBoundary+self.offset:
            self.done_flag      = True 
            self.reward        += self.fail_policy
        elif self.boatX > self.rightBoundary-self.offset:
            self.done_flag      = True 
            self.reward        += self.fail_policy
        elif self.boatY > self.backBoundary-self.offset:
            self.done_flag      = True 
            self.reward        += self.fail_policy
        elif self.boatY < self.frontBoundary+self.offset:
            self.done_flag      = True 
            self.reward        += self.fail_policy
        elif n_steps > self.max_steps:
            self.done_flag      = True 
            self.reward        += self.fail_policy
        else:
            self.done_flag      = False
        #
        self.observation         = np.array([self.boatX,self.boatY,
                                             self.boatvx,self.boatvy,
                                             self.boatYaw,self.yawSpeed,self.rudderAngle,self.targetX,self.targetY,self.distance2taget],dtype=np.float32) 
        #
        # reward policy:
        #   reaching wayPoint       +   done_flag
        #   distance traveled       +
        #   time taked              -
        #   schooling               -
        #   reaching domainlimit    -   done_flag
        # ...
        #
        #print(f"Boat Rudder Angle Change: {self.rudderAngleDelta}")
        #print(f"Boat Rudder Angle: {self.rudderAngle}")
        #print(f"Boat Rudder Projected Area: {self.rudderProjectedArea}")
        #print(f"Boat Yaw: {self.boatYaw}")
        #print(f"Boat Yaw Speed: {self.yawSpeed}")
        #print(f"Boat Yaw Acceleration: {self.yawAcceleration}")
        #print(f"Boat Heading Vector: {self.boatHeading}")
        #print(f"Boat Location Vector: {self.boatX,self.boatY}")
        #print(f"Boat speed Vector: [{self.boatvx},{self.boatvy}], {self.boatSpeed}")
        #print(f"Traveled distance: {self.travelRatio}")
        #print(f"Reward: {self.reward}")
        #
        return self.observation, self.reward, self.done_flag



class LinearDeepQReplayNetwork_class(nn.Module):
    # This is the replay network, wich is almost always required
    # It classifies discrete actions based on continous observations about location, velocities and acceleration
    #
    #def __init__(self,learning_rate=0.9,input_dims=np.arange(8),fc1_dims=10,fc2_dims=8,n_actions=4):
    #def __init__(self,learning_rate=0.9,input_dims=8,fc1_dims=10,fc2_dims=8,n_actions=4):
    def __init__(self,learning_rate,input_dims,fc1_dims,fc2_dims,n_actions,name):
        # a DeepQ network is an estimate of the value of each action, ginven some environmental states
        """
        learning_rate: learning rate
        input_dims: number of inputs / observation vector
        fc1_dims: number of hidden neurons in the firls layer
        fc2_dims: number of hidden neurons in the firls layer
        n_actions: number of possible actions to select (classification problem?)
        """
        super().__init__()
        #super(LinearDeepQReplayNetwork_class,self).__init__()
        self.input_dims = input_dims
        self.fc1_dims = fc1_dims
        self.fc2_dims = fc2_dims
        self.n_actions = n_actions
        self.name  = name # name of the nn 
        #
        #lets create some layers
        self.fc1 =  nn.Linear(self.input_dims,self.fc1_dims)
        #self.fc1 =  nn.Linear(*self.input_dims,self.fc1_dims) #check123
        # with * we unpack a list, we pass the elemets of the observation vector
        # this will facialitate the  creation of convolutional networks, or an environment that has 2 dimentional matrix as input
        #
        self.fc2 =  nn.Linear(fc1_dims,self.fc2_dims)
        self.fc3 =  nn.Linear(fc2_dims,self.n_actions) # a DeepQ network is an estimate of the value of each action, ginven some environmental states
        #
        # lets define the optimizer
        self.optimizer = optim.Adam(self.parameters(),lr = learning_rate)
        #
        # lets define the Loss function
        self.loss = nn.MSELoss()
        #
        #lets selct a device
        self.device = T.device('cuda:0' if T.cuda.is_available() else 'cpu')
        #
        # lets send the network to the device
        self.to(self.device)
        #
        print(f"{self.name} Network Created")
    #
    #lets define the forward pass
    def forward(self,state):
        x = F.relu(self.fc1(state))
        x = F.relu(self.fc2(x))
        self.action_chosen = self.fc3(x)
        # we do not want to activate (use Relu) the action because we want the agents to get the raw estimate 
        return self.action_chosen


class agentDQN():
    # What the agent wants to know for the temporal difference update rule policyis
    #   current state, next state, reward recieved, action it took to receirve such reward
    # DeepQ Learning is a model-free bootstraped all policy learning method, so it does not care about the dynamics of the environmet,
    # it would figure out those dynamics by itelf (model-free). It constructs estimated of action value functions, 
    # this is the weight of each action give a certain state, using one stimate to build another estimate (boottrap)
    # all policy means that it has a policy (epsilon ration) to generate reandom actions
    #
    #def __init__(self,gamma=0.7,epsilon=0.9,learningRatio=0.8,input_size = 2,batch_size=10,num_actions=4,
    #             max_memori_size=100_000,epsilon_end = 0.01,epsilon_delta = 5e-4):
    def __init__(self,gamma,epsilon,learningRatio,input_size,batch_size,num_actions,
                 max_memori_size=100_000,epsilon_end = 0.01,epsilon_delta = 5e-4,reload_path=[],):
        #gamma: determines the weights of future rewards
        #epsilon: exploit - explore rate
        #learningRatio of the DeepQ Replay Network
        # batch_size: after certain number of memories (batch_size) the network parameter will by updated using Adam
        # input_size : state for location, orientation, rudder / wheel angle, main sheep angle/ floorin pedal angle 
        #num_actions : number of possible actions: turn rudder / steering wheel, go faster / slower / recover / loose main sheet 
        #epsilon_end : percentage of the time we take the exploration approach
        #epsilon_delta: decrement in epsilon after each time step (linear approach) 
        #   After some time of acting randomly epsilonit will decay overtime
        self.gamma          = gamma
        self.epsilon        = epsilon
        self.learningRatio  = learningRatio
        self.batch_size     = batch_size
        self.n_actions      = num_actions
        self.memory_size    = max_memori_size
        self.epsilon_min     = epsilon_end
        self.eps_delta      = epsilon_delta
        #
        self.action_space   = [ii for ii in range(num_actions)] 
        # this list comprehensions gives a representation of the available actions
        # this is used in the action selection greedy algorithm
        #
        self.mem_cntr = 0
        # keeps tract of the first available memory for storing the agents memory
        #
        #lets define an object to predict future Q values / best action weights
        # this is the policy network
        self.Q_eval = LinearDeepQReplayNetwork_class(self.learningRatio,input_dims=input_size,fc1_dims=256,fc2_dims=256,n_actions=self.n_actions,name='Q_eval')
        #
        # lets define the target / critic network
        self.target_net = LinearDeepQReplayNetwork_class(self.learningRatio,input_dims=input_size,fc1_dims=256,fc2_dims=256,n_actions=self.n_actions,name='Target_net')        
        # at the beginning lets make that the traget network has the same weights than the Q-network
        if len(reload_path) > 1:
            self.Q_eval.load_state_dict(T.load(f"{reload_path[0]}"))
            self.target_net.load_state_dict(T.load(f"{reload_path[1]}"))
            print(f"State dictionaries of eval and target neworks loaded!")
        else:
            self.target_net.load_state_dict(self.Q_eval.state_dict() )
        #
        # based on Q valuues, we select a certain action
        # can we fine-tune this using a model of lunar lander, car, sail boat???
        #
        # lets define memory arrays. 
        #self.state_memory = np.zeros((self.memory_size,*input_size),dtype=np.float32) # for keep track of previous states
        #check123
        #self.previous_state_memory = np.zeros((self.memory_size,*input_size),dtype=np.float32) # for state comparison
        #check123
        self.state_memory = np.zeros((self.memory_size,input_size),dtype=np.float32) # for keep track of previous states
        self.new_state_memory = np.zeros((self.memory_size,input_size),dtype=np.float32) # for state new states
        self.action_memory = np.zeros(self.memory_size,dtype=np.int32) # for keeping track of previous actions
        # np.int8
        self.reward_memory = np.zeros(self.memory_size,dtype=np.float32) # for keeping track of previous rewards
        self.episode_steps = np.zeros(self.memory_size,dtype=np.int32) # for keeping track of number of transitions
        # np.int12
        self.terminal_memory = np.zeros(self.memory_size,dtype=np.bool_) # for keeping track of previous atttemps / games
        #
        print("Agent for the Game Created")
        #print(self.memory_size,input_size,np.shape(self.state_memory))
        #
    def store_transition(self,state1_, action,reward,state2_,done):
        # method for storing past experience
        #
        index = self.mem_cntr % self.memory_size
        self.state_memory[index] = np.array(state1_,dtype = np.float32)
        self.new_state_memory[index,:] = state2_
        self.action_memory[index] = action
        self.reward_memory[index] = reward
        self.terminal_memory[index] = done # either a 0 or 1
        #
        self.mem_cntr += 1 # we filled a memory space, so we need to increas the memory counter by 1
    def store_transition(self,state1_, action,reward,state2_,episode_steps,done):
        # method for storing past experience
        #
        index = self.mem_cntr % self.memory_size
        self.state_memory[index] = np.array(state1_,dtype = np.float32)
        self.new_state_memory[index,:] = state2_
        self.action_memory[index] = action
        self.reward_memory[index] = reward
        self.episode_steps[index] = episode_steps
        self.terminal_memory[index] = done # either a 0 or 1
        #
        self.mem_cntr += 1 # we filled a memory space, so we need to increas the memory counter by 1
        #
    def folder_setup(self,parentFolder="sailingBoatModel101"):
        #generation of folder for saving results
        self.fileTypeError1 = 0
        self.fileTypeError2 = 0
        try:
            os.mkdir(parentFolder)
            self.path_frames = f"./{parentFolder}/frames"
            os.mkdir(self.path_frames)
            self.path_succes = f"./{parentFolder}/successfull"
            os.mkdir(self.path_succes)
            self.path_max_score = f"./{parentFolder}/max_score"
            os.mkdir(self.path_max_score)
            self.path_max_avg_score = f"./{parentFolder}/max_avg_score"
            os.mkdir(self.path_max_avg_score)
            self.path_final_score = f"./{parentFolder}/final_score"
            os.mkdir(self.path_final_score)
            self.path_freq = f"./{parentFolder}/freq"
            os.mkdir(self.path_freq) 
            self.path_stats = f"./{parentFolder}/stats"
            os.mkdir(self.path_stats)
        except FileExistsError:
            newFolder = f"sailingBoatModel_temp_{str(np.random.randint(100))}"
            print(f"Folders aready created, changing parent folder to a random name: {newFolder}")
            self.folder_setup(newFolder)
            self.fileTypeError1 += 1
        except:
            print("Unknown error")
            self.fileTypeError2 += 1
        finally:
            print(f"Any error type while setting up folders? {self.fileTypeError1},{self.fileTypeError2}")
            #val = input()
        #
    def save_state(self,message,path,ii):
        #saving state of the agent and replay network
        T.save(self.Q_eval.state_dict(),f"{path}/Q_eval_stateDict_{message}.pt")
        T.save(self.target_net.state_dict(),f"{path}/target_net_stateDict_{message}.pt")
        #model = agentDQN(*args, **kwargs)
        #model.load_state_dict(T.load(f"{path}/Q_eval_stateDict_{message}.pt"))
        #model.eval() # you must call model.eval() to set dropout and batch normalization layers to evaluation mode before running inference. Failing to do this will yield inconsistent inference results.
        T.save(self.Q_eval,f"{path}/Q_eval_{message}.pt")
        T.save(self.target_net,f"{path}/target_net_{message}.pt")
        #model = T.load(f"{path}/Q_eval_stateDict_{message}.pt")
        #model.eval() # you must call model.eval() to set dropout and batch normalization layers to evaluation mode before running inference. Failing to do this will yield inconsistent inference results.
        #
        #https://stackoverflow.com/questions/4529815/saving-an-object-data-persistence
        with open(f'{path}/Q_eval_{message}.pkl', 'wb') as outp:
            pickle.dump(self.Q_eval, outp, pickle.HIGHEST_PROTOCOL)
        with open(f'{path}/target_net_{message}.pkl', 'wb') as outp:
            pickle.dump(self.target_net, outp, pickle.HIGHEST_PROTOCOL)
        #with open(f'{path}/Q_eval_{message}.pkl', 'rb') as inp:
        #    self.Q_eval_2 = pickle.load(inp)
        with open(f'{path}/model_folder_{message}.pkl', 'wb') as outp:
            pickle.dump(self, outp, pickle.HIGHEST_PROTOCOL)
        #with open(f'{path}/model_folder{message}.pkl', 'rb') as inp:
        #    test_agent = pickle.load(inp)
        #    print(f"Checking loaded model {test_agent.mem_cntr}")  

        dict1 = {'x1':self.state_memory[:,0],
                 'y1':self.state_memory[:,1],
                 'u1':self.state_memory[:,2],
                 'v1':self.state_memory[:,3],
                 'yaw1':self.state_memory[:,4],
                 'yawSpeed1':self.state_memory[:,5],
                 'rudderAngle1':self.state_memory[:,6],
                 'targetx1':self.state_memory[:,7],
                 'targety1':self.state_memory[:,8],
                 'distance2target1':self.state_memory[:,9],
                 'x2':self.new_state_memory[:,0],
                 'y2':self.new_state_memory[:,1],
                 'u2':self.new_state_memory[:,2],
                 'v2':self.new_state_memory[:,3],
                 'yaw2':self.new_state_memory[:,4],
                 'yawSpeed2':self.new_state_memory[:,5],
                 'rudderAngle2':self.new_state_memory[:,6],
                 'targetx2':self.new_state_memory[:,7],
                 'targety2':self.new_state_memory[:,8],
                 'distance2target2':self.new_state_memory[:,9],
                 'Actions_rudder2port':self.action_memory[0],
                 'Actions_doNothing':self.action_memory[1],
                 'Actions_rudder2stardBoard':self.action_memory[2],
                 'Rewards':self.reward_memory,
                 'Number_of_steps' : self.episode_steps,
                 'Finish_Flag':self.terminal_memory
                       }
        df = pd.DataFrame( dict1 )
        #df.to_csv(f"sailing_telemetry.csv", sep='\t', encoding='utf-8',index=False)
        df.to_csv(f"{path}/sailing_telemetry.csv", sep=';', encoding='utf-8',index=False)
        #
        #
        os.system(f'cp {self.path_frames}/Frame_{ii}*.png {path}') # saving frames to folder
        #
        #
    def evalModel(self):
        self.Q_eval.eval()
        self.target_net.eval()
        #
        #
    def saveSuccesfull(self,ii):
        os.system(f'cp {self.path_frames}/Frame_{ii}*.png {self.path_succes}/') # saving frames to folder     
        #
        #
    def radom_action_selection(self):
        #
        # exploration approach
        action = np.random.choice(self.action_space)
        #
        return action

        #
    def action_selection(self,observation):
        #
        #method for chosing actions
        # observation : environmental state
        #
        if np.random.random() > self.epsilon: # np.random.random() -> random sample from [0,1)
            # exploitations approach, we estimate the weights of the best known actions
            # as epsilon decreases, the agent will tent to choose a greedy action,  that is,
            # the action that has the greatest value of the next state

            #
            #we convert the observations into a torch tensor (state matrix usable by the forward method of the replay network)
            #and we senf this to the device, we need to send the variales on which we want to make computations onto the computing device
            state = T.tensor(observation).to(self.Q_eval.device) # the network is set up in a way in which we need to use [] in [observation]
            #state = T.tensor([observation]).to(self.Q_eval.device) # in case oversvation is not a numpy array
            #check123
            #
            actions_raw_vals = self.Q_eval.forward(state) #action weights
            #print(f"Action raw vals:{actions_raw_vals}")
            #lets select the action with the largest weight
            action = T.argmax(actions_raw_vals).item() #without .item() we get a tensor
            #
        else:
            # exploration approach
            action = np.random.choice(self.action_space)
            #print("Waring: a random action was taken!")
        #
        return action
    #
    #
    #Method where the agent learns from pasts experiences
    def learn(self):
        #We need to olve the dilema of how we learn from pasts memories
        # we can play randomly to acquire a baseline for a while and then we start learning
        if self.mem_cntr < self.batch_size:
            return
        #
        #print(f"Learning Phase, couner value# {self.mem_cntr}")
        # or we can start learning rightaway:
        self.Q_eval.optimizer.zero_grad() # Resets the gradients of all optimized torch.Tensor s.
        #
        # lets calculate the position of the maximum memory, we just want to select until the last filled memory slot
        # we take the minimum value of:
        #print(f"self.mem_cntr {self.mem_cntr}")
        #print(f"self.memory_size {self.memory_size}")
        max_memory = min(self.mem_cntr,self.memory_size)
        #print(f"max_memory {max_memory}")
        #
        # lets create a batch of memories to train
        batch = np.random.choice(max_memory,self.batch_size,replace=False)# replace = False -> this way we avoid selecting the same memory more than once
        #print(F"batch {batch}")
        #This way, once we select a memoy we take it out of the pool of available memories
        # batch is an array of indexes, of size batch_size, randomly slected for this array: [0,1,3,...,max_memory-1]
        #
        # we need batch_index and action_index to perform a proper array slicing 
        batch_index = np.arange(self.batch_size,dtype=np.int32) #[0,1,...,self.batch_size-1]
        #print(f"batch_index {batch_index}")
        #
        # using the list of random indexes in batch, lets select some memories
        #lets convert a numpy arrray subset of the agent memories into torch tensor and sen it to the device
        state_batch = T.tensor(self.state_memory[batch]).to(self.Q_eval.device)
        #print(f"state_batch {state_batch}")
        #
        #lets do the same for new states, rewwards and terminated atemps
        new_state_batch = T.tensor(self.new_state_memory[batch]).to(self.Q_eval.device)
        reward_batch = T.tensor(self.reward_memory[batch]).to(self.Q_eval.device)
        n_episodes_batch = T.tensor(self.episode_steps[batch]).to(self.Q_eval.device)#check123
        terminal_batch = T.tensor(self.terminal_memory[batch]).to(self.Q_eval.device)
        #
        action_batch = self.action_memory[batch]
        #
        #feedforward for getting values to use in the loss function. We are passing an array of memories, and for each memory we 
        #forecast which action is the best based of its forecasted weight. So we end up geting a matrix as a results so we need to estact
        # using [batch_index,action_batch]
        q_eval = self.Q_eval.forward(state_batch)[batch_index,action_batch] # we extract the values of the actions we actually took
        #print(f"q_eval {q_eval}")
        #
        #check123
        #q_next = self.Q_eval.forward(new_state_batch)# instead of this we can use a target network
        with T.no_grad():
            q_next = self.target_net.forward(new_state_batch)
        #print(f"q_next {q_next}")
        q_next[terminal_batch] = 0.0
        #print(f"q_next {q_next}")
        #print(f"reward_batch {reward_batch}")
        #print(f"self.gamma {self.gamma}")
        #
        #lets compute new q values with a greedy aproax (we use max() ) using info from q_next (future q values)
        q_target = reward_batch + self.gamma * T.max(q_next,dim = 1)[0] # this max retunrs the value and the index, we only need the value
        #dims = 1 -> we perform the max opteration along the rows / action dimension
        #
        #lets comute the loss function
        # we send all info to the device
        loss = self.Q_eval.loss(q_target,q_eval).to(self.Q_eval.device)
        #print(f"Loss: {np.mean(loss.item()):.3f}")
        print(f"\rLoss: {np.mean(loss.item()):.3f}\r")
        #
        #next we comupte the back propagation steps
        loss.backward()
        #
        #check123
        # In-place gradient clipping
        #max_value = 100 # To prevent exploding gradients
        #T.nn.utils.clip_grad_value(self.Q_eval.parameters(),max_value)#check123
        """ https://saturncloud.io/blog/how-to-do-gradient-clipping-in-pytorch/
        During training, we use the clip_grad_norm_ function to clip the gradients of the neural network parameters to 
        a maximum norm of 1.0. This ensures that the gradients are scaled down to a reasonable size, preventing exploding 
        gradients.
        Choosing the Maximum Gradient Norm Value
        The maximum gradient norm value that you use for gradient clipping depends on the specific model and dataset that 
        you’re working with. In general, you should choose a value that is large enough to allow the model to learn quickly, 
        but small enough to prevent exploding gradients.
        A good starting point for the maximum gradient norm value is 1.0, as shown in the example above. You can experiment 
        with different values to see what works best for your model and dataset.
        """
        # we update replay network weights
        self.Q_eval.optimizer.step()
        #
        #filally we decrease the value of the exploration ratio
        self.epsilon = self.epsilon - self.eps_delta if self.epsilon > self.epsilon_min else self.epsilon_min


def main_training2sail():
    #
    #Hyperparameter definition
    Gamma           = 0.99#1-1.618#0.99 #update ratio for Q values
    Epsilon         = 1 # this way the agent takes random values at the beggining # -1 this way we only apply the egent's policy and no random action is taken 
    Batch_size      = 64#64#128#1684#64
    Learning_ratio  = 0.0001618#0.0001
    Input_size      = 10 #[8] # rudder game -> [x,y,vx,vy,yaw,yawSpeed,rudderAngle,targetX,targetY,distance2target]
    Num_actions     = 3 #move the finn of the rudder 30 to port, do nothing, move the finn of the rudder 30 to stardboard.
    Max_memori_size = 100_000#100*1618#100_000
    Epsilon_delta   = 1.618e-4#1.618e-4#1.618e-6#5e-4
    Epsilon_end     = 0.01618#0.01
    #lets define for how long does the agent need to learn
    Learning_time   = 7400
    n_episodes      = Learning_time+200+200 #n_episodes/1.618+(n_episodes - n_episodes/1.618)#500
    maxSteps        = 200 # 5_000 # maximun number of state transions per episode
    tau             = 0.001#0.05#1/Learning_time #0.005 # Update rate of the target network
    #
    timePolicy      = -0.005*0.2#-0.1 # penalty for time taken to land the spaceCraft
    successPolicy   = 100 #1000
    failPolicy      = -200 #3000
    distancePolicy  = 1
    targetRadius    = 2 # [m]
    #
    avg             = 100 #number of samples to compute average score
    save_ep         = 200 # freq for saving results
    #
    n_start         = 0 #3800+3400
    modelPath       = "./model_folder_ep_3400_mem_counter_508978_freq_200_eps_0.016.pkl"
    reloadPath      = ["Q_eval_stateDict_ep_2257_mem_counter_274108_max_avg_score_225.26_eps_0.016.pt","target_net_stateDict_ep_2257_mem_counter_274108_max_avg_score_225.26_eps_0.016.pt"]
    #
    np.random.seed(32)
    T.manual_seed(32)
    folderName      = f"sailingBoatModel" #parent folder for saving results
    env101          = sea_environment(time_policy = timePolicy,
                                      success_policy = successPolicy,
                                      fail_policy = failPolicy,
                                      distance_policy = distancePolicy,
                                      target_radius = targetRadius,
                                      max_steps= maxSteps)
    #reloadPath = ["Q_eval_stateDict_ep_1600_mem_counter_216242_freq_200_eps_0.016.pt","target_net_stateDict_ep_1600_mem_counter_216242_freq_200_eps_0.016.pt"]
    agent101        = agentDQN(gamma=Gamma,
                                epsilon=Epsilon,
                                learningRatio=Learning_ratio,
                                input_size=Input_size,
                                batch_size=Batch_size,
                                num_actions=Num_actions,
                                max_memori_size=Max_memori_size,
                                epsilon_end=Epsilon_end,
                                epsilon_delta=Epsilon_delta)#,reload_path=reloadPath)
    """with open(modelPath, 'rb') as inp:
        agent101 = pickle.load(inp)
        print(f"Checking loaded model {agent101.mem_cntr}")  
        """
    agent101.folder_setup(folderName) #creation of forders for saving results
    framesDir      = agent101.path_frames
    #
    # variable for keepin track of number of steps reward scores, and episodes
    n_transition_steps = []
    scores = []
    episodes_history = []
    avg_score_list  = []
    #Initializing SCORE FOR KEEPING TRACK OF THE BEST PERFORMING MODELS
    max_score       = -100 
    max_avg_score   = -100
    avg_score       = 0
    #
    for ii in range(n_start,n_episodes+1):
        #
        env101.reset()
        print(f"\n\n\n Starting new journey for being ahead of ready...\n\t...All the great journeys start with a single step\n\n")
        episode_steps   = 0 # Step index
        score           = 0
        state1 = env101.get_InitialObservation()
        #
        done_flag = False # flag to inidicate if the saoiling journey can continue
        while( not(done_flag)):
            episode_steps  +=1
            action = agent101.action_selection(state1) #            agent101.radom_action_selection()
            state2, reward, done_flag = env101.get_observation(action,episode_steps)
            score += reward
            agent101.store_transition(state1,action,reward,state2,episode_steps,done_flag)
            env101.plot_environment(ii,episode_steps,score,framesDir)
            #print(f"======= Episode#{ii}, Transition Step #{episode_steps} ======= ")
            #print(f"Action selected: {action}")
            #print(f"Observation: {state2}")
            #print(f"Score / Reward: {score}/{reward}")
            #print(f"Flag: {done_flag}")
            #
            # next we try to learn smth from past experiences
            if ii < Learning_time:
                agent101.learn()
                # lets do the soft update of the target network
                target_net_stateDict = agent101.target_net.state_dict()
                policy_net_stateDict = agent101.Q_eval.state_dict()
                #print(agent101.target_net.state_dict())
                #val = input()
                for key in policy_net_stateDict:
                    target_net_stateDict[key] = policy_net_stateDict[key]*tau + target_net_stateDict[key]*(1-tau)
                    #
                agent101.target_net.load_state_dict(target_net_stateDict)
            else:
                agent101.evalModel()
                agent101.epsilon = 0
                #
            state1 = state2
            #
            #env101.pr_bar(episode_steps,maxSteps)
            pr_bar(episode_steps-1,maxSteps)

        ##
        ##
        print(f"\n============================ End of Episode #{ii},\n\n\tfinal exploration ratio (epsilon): {agent101.epsilon:.3f}, number of transitions: {episode_steps}, memory counter: {agent101.mem_cntr}, last reward: {reward:.2f}, \n\n\tState:{state2}\n" )
        n_transition_steps.append(episode_steps)
        scores.append(score)
        episodes_history.append(agent101.epsilon)
        #lets comute the scores of the last 100 transition steps
        avg_score = np.mean(scores[-avg:])
        avg_score_list.append(avg_score)
        #avg_score =np.mean(scores)
        print(f"\n\tavg. score from the last {avg} episodes:{avg_score:.2f}/{max_avg_score:.2f},\n\n\tfinal score:{score:.2f}/{max_score:.2f}\n\n\n")
        #
        #if reward > 80:
        #    agent101.saveSuccesfull(ii)
        #
        try:
            if avg_score > max_avg_score:
                max_avg_score = avg_score
                print(f"New max average score {max_avg_score:.2f}")
                message = f"ep_{ii}_mem_counter_{agent101.mem_cntr}_max_avg_score_{max_avg_score:.2f}_eps_{agent101.epsilon:.3f}"
                agent101.save_state(message,agent101.path_max_avg_score,ii)
            if score > max_score:
                max_score = score
                print(f"New max score {max_score:.2f}")
                message = f"ep_{ii}_mem_counter_{agent101.mem_cntr}_max_score_{max_score:.2f}_eps_{agent101.epsilon:.3f}"
                agent101.save_state(message,agent101.path_max_score,ii)
            if ii%save_ep == 0:
                message = f"ep_{ii}_mem_counter_{agent101.mem_cntr}_freq_{save_ep}_eps_{agent101.epsilon:.3f}"
                agent101.save_state(message,agent101.path_freq,ii)
                #
                os.system(f"rm {framesDir}/*.png ") # removing previous frames
                #lets plot some results
                x = [jj+1 for jj in range(n_start-1,ii)]
                fileName = f"{agent101.path_stats}/model_learning_plot.png"
                #env101.plot_learning_curve_ap(x,scores,episodes_history,fileName)
                plot_learning_curve_ap(x,avg_score_list,episodes_history,fileName)
                fileName = f"{agent101.path_stats}/model_learning_plot_avg_score.png"
                #env101.plot_learning_curve_averageScore(x,scores,episodes_history,fileName)
                plot_learning_curve_averageScore(x,avg_score_list,fileName)
                fileName = f"{agent101.path_stats}/model_episode_steps_score.png"
                #env101.plot_learning_curve_totalScore_steps(x,scores,n_transition_steps,fileName)
                plot_learning_curve_totalScore_steps(x,scores,n_transition_steps,fileName)   
        except:
            print(f"WARNING! model could no be saved")
        #
    #lets plot some results
    x = [jj+1 for jj in range(n_start-1,n_episodes)]
    message = f"final_avg_score_{avg_score}_max_score_{max_score}_score_{score}_mem_counter_{agent101.mem_cntr}_eps_{agent101.epsilon:.3f}"
    agent101.save_state(message,agent101.path_final_score,ii)
    fileName = f"{agent101.path_stats}/model_learning_plot.png"
    #env101.plot_learning_curve_ap(x,scores,episodes_history,fileName)
    plot_learning_curve_ap(x,avg_score_list,episodes_history,fileName)
    fileName = f"{agent101.path_stats}/model_learning_plot_avg_score.png"
    #env101.plot_learning_curve_averageScore(x,scores,episodes_history,fileName)
    plot_learning_curve_averageScore(x,avg_score_list,fileName)
    fileName = f"{agent101.path_stats}/model_episode_steps_score.png"
    #env101.plot_learning_curve_totalScore_steps(x,scores,n_transition_steps,fileName)
    plot_learning_curve_totalScore_steps(x,scores,n_transition_steps,fileName)
    #

if __name__ == '__main__':
    main_training2sail()
