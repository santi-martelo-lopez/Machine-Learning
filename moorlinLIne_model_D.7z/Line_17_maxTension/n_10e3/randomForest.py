# How to run this program:
"""
python3 randomForest.py
start conda init base | python randomForest.py
start conda init base | python randomForest.py > randomForest_log.txt 
"""
# #
##################################################################################
###                                                                           ###
###                                IMPORTING LIBRARIES                        ###
###                                                                           ###
##################################################################################
import sklearn
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import seaborn as sns
#
from sklearn.tree import DecisionTreeRegressor, DecisionTreeClassifier
from sklearn.tree import plot_tree # for plotting decission tree
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import AdaBoostRegressor
from sklearn.model_selection import GridSearchCV
import xgboost as xgb
#
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Ridge
#
# Allows us to test parameters of classification algorithms and find the best one
from sklearn.model_selection import GridSearchCV
#
from sklearn import metrics
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import jaccard_score
from sklearn.metrics import f1_score
from sklearn.metrics import log_loss
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import cross_val_score
#
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
from sklearn.metrics import roc_curve
from sklearn.metrics import RocCurveDisplay
from sklearn.metrics import auc
# 
# 
import warnings
#warnings.filterwarnings('ignore')
pd.set_option('display.max_columns',100)
pd.set_option('display.min_rows',10)
pd.set_option('display.max_rows',1000)
pd.set_option('display.width',200)
pd.set_option('expand_frame_repr',100)
pd.set_option('display.max_colwidth',100)
# #
#
#
##################################################################################
###                                                                           ###
###                                SYSTEM PARAMETERS                          ###
###                                                                           ###
##################################################################################
# #
figureSize                      = (20,14)
maxSamples                      = 9999
targetColumnValue               = -29
ccpAlphaVec                     = [0.005,0.001,0.005] #[0.001,0.01,0.1]   # [0.001,0.01,0.05] 
#targetColumn = df_cols_maxTarget[-1] #Tensions in mooring line 45
#targetColumn = df_cols_maxTarget[-40] #Tensions in mooring line 5
#targetColumn = df_cols_maxTarget[-29] #Tensions in mooring line 17
#targetColumn = df_cols_maxTarget[-17] #Tensions in mooring line 29
#targetColumn = df_cols_maxTarget[-5] #Tensions in mooring line 41
runX                            = 1500
cv_val                          = 3
ramdomState                     = 42 # -> R^2_test = 1.00, R^2_test = 0.98 in decision trees
shuffleFlag                     = True #False -> R^2_test = 1.00, R^2_test = 0.98 in decision trees
testSize                        = 0.30 # 0.2 -> R^2_test = 1.00, R^2_test = 0.98 in decision trees
numberOfLines                   = 11 + 12 + 11 + 12
maximumTension                  = 2.97e4 #[N] folch_nylon_14mm.mc
safetyMargin                    = .07
#Threshold tension force
#maximumTension = 2.97e4 #[N] folch_nylon_14mm.mc
#safetyMargin = .07
threshold_force = maximumTension*safetyMargin #2000 #[N]
print(f"Threshold tension force {threshold_force} #[N]")
#
#
label                           = "b_30_years"
testingFeature                  = label
path_pkl                        = f"{label}_maxFeatures.pkl"
data                            = pd.read_pickle(f"../../{path_pkl}")
#
#
label_lifeCycle                 = "b_30_years"
path_pkl                        = f"{label_lifeCycle}_maxFeatures.pkl"
#data = pd.read_pickle(f"../../{path_pkl}")
path_lifeCycle                  = "C:/Users/martelos/Documents/Documents/febo/workbench/cases/LLIRIA_anchorLift_0_97m/c_resulsDir"
data_lifeCycle                  = pd.read_pickle(f"{path_lifeCycle}/{path_pkl}")
# 
# 
#
# #
##################################################################################
##################################################################################
###                                                                           ###
###                            FUNCTION DEFINITIONS                           ###
###                                                                           ###
##################################################################################
##################################################################################
def plot_ml_regressor_predictionVStarget_values(figureSize,label,predictions_train, y_train,predictions_test, y_test) -> None:
    """
    function for ploting the predicted tensions by machine models against target values, 
    obtained with simulations or meassurements
    """
    fig, ax = plt.subplots(figsize = figureSize)
    #plt.plot(predictions_train, y_train, "+", color="blue",linestyle="--",alpha = 0.7)
    #plt.plot(predictions_test, y_test, "^", color="red",linestyle="--",alpha = 0.7)
    plt.plot(predictions_train, y_train, "+", color="blue",alpha = 0.7)
    plt.plot(predictions_test, y_test, "^", color="red",alpha = 0.7)
    #plt.legend(["Traning Stage","Validation Stage"],loc=2,prop={'size':22})
    plt.legend(["Traning Stage","Validation Stage"],prop={'size':22})
    #
    plt.xlim(min(min(predictions_train),min(predictions_test)),max(max(predictions_train),max(predictions_test)))
    plt.ylim(min(min(predictions_train),min(predictions_test)),max(max(predictions_train),max(predictions_test)))
    #plt.xticks(range(100,220,20))
    plt.xticks(fontsize=15)
    plt.yticks(fontsize=15)
    plt.minorticks_on()
    plt.grid()
    ax.tick_params(which='both', width=2)
    ax.tick_params(which='major', length=10)
    ax.tick_params(which='minor', length=7, color='orange')
    #
    plt.xlabel('ML Tension Predictions [N]',fontsize=20)
    plt.ylabel('FEBO Tension Predictions [N]',fontsize=20)
    plt.title('Tension Prediction Comparison',fontsize=30)
    #
    plt.savefig(f'{label}_predicted_vs_simulated.png')
# 
# 
# #
##################################################################################
##################################################################################
def plot_ml_regressor_lifeCycle_predictionVStarget_values(figureSize,label,prediction_lifeCycle, y_lifeCycle) -> None:
    """
    function for ploting the Life Cycle predicted tensions by machine models against target values, 
    obtained with simulations or meassurements
    """
    fig, ax = plt.subplots(figsize = figureSize)
    #plt.plot(predictions_train, y_train, "+", color="blue",linestyle="--",alpha = 0.7)
    #plt.plot(predictions_test, y_test, "^", color="red",linestyle="--",alpha = 0.7)
    plt.plot(predictions_lifeCycle, y_lifeCycle, "^", color="red",alpha = 0.7)
    plt.plot(y_lifeCycle, y_lifeCycle, "+", color="blue",alpha = 0.7)
    #plt.legend(["Traning Stage","Validation Stage"],loc=2,prop={'size':22})
    plt.legend(["ML Predictions","Life Cycle Values"],prop={'size':22})
    #
    plt.xlim(min(min(y_lifeCycle),min(predictions_lifeCycle)),max(max(predictions_train),max(y_lifeCycle)))
    plt.ylim(min(min(y_lifeCycle),min(predictions_lifeCycle)),max(max(predictions_train),max(y_lifeCycle)))
    #plt.xticks(range(100,220,20))
    plt.xticks(fontsize=15)
    plt.yticks(fontsize=15)
    plt.minorticks_on()
    plt.grid()
    ax.tick_params(which='both', width=2)
    ax.tick_params(which='major', length=10)
    ax.tick_params(which='minor', length=7, color='orange')
    #
    plt.xlabel('ML Tension Predictions [N]',fontsize=20)
    plt.ylabel('FEBO Tension Predictions [N]',fontsize=20)
    plt.title('Tension Prediction Comparison',fontsize=30)
    #
    plt.savefig(f'{label}_predicted_vs_simulated.png')
# 
# 
# #
##################################################################################
##################################################################################
def plot_ml_regressor_predictionVStarget_values_idSamples(figureSize,labelFigure,predictions,y,titleText) -> None:
    """
    function for ploting the predicted tensions by machine models against target values, 
    obtained with simulations or meassurements
    """
    fig, ax = plt.subplots(figsize = figureSize)
    pd.Series(y).reset_index(drop=True).plot()
    pd.Series(predictions).plot()
    plt.legend(["FEBO","ML"],prop={'size':22})
    #
    plt.xticks(fontsize=15)
    plt.yticks(fontsize=15)
    plt.minorticks_on()
    plt.grid()
    ax.tick_params(which='both', width=2)
    ax.tick_params(which='major', length=10)
    ax.tick_params(which='minor', length=7, color='orange')
    #
    plt.xlabel('Sample ID',fontsize=20)
    plt.ylabel('Tension Predictions [N]',fontsize=20)
    plt.title(f'{titleText.replace("_"," ")} Tension Prediction',fontsize=30) #Validation Stage
    #
    plt.savefig(f'{labelFigure}_predicted_vs_simulated_{titleText}.png')
# 
# 
##################################################################################
##################################################################################
def scoringTest(model,X_train, y_train,X_test, y_test,label): 
    # R^2 Pearson's coefficient
    R2_train = r2_score(predictions_train, y_train)
    R2_test = r2_score(predictions_test, y_test)
    modelScore_train = model.score(X_train, y_train)
    modelScore_test = model.score(X_test, y_test)
    mea_train = mean_absolute_error(predictions_train, y_train)# mea : mean absolute error
    mea_test  = mean_absolute_error(predictions_test, y_test)
    rmse_train = np.sqrt(mean_squared_error(predictions_train, y_train))# rmse : Root mean square error
    rmse_test  = np.sqrt(mean_squared_error(predictions_test, y_test))
    #
    resultsLog = [
    f"Scoring results for model {label}",
    f"model: {model}",
    f"number of sampples: {n_samples}",
    f"R2 in training stage: {modelScore_train:.3f}",
    f"R2 in testing stage: {modelScore_test:.3f}",
    f"Pearson's coefficient in training stage: {R2_train:.3f}",
    f"Pearson's coefficient in testing stage: {R2_test:.3f}",
    f"Mean absolute error in training stage: {mea_train:.3f}",
    f"Mean root square error in training stage: {rmse_train:.3f}",
    f"Mean absolute error in testing stage: {mea_test:.3f}",
    f"Root mean square error in testing stage: {rmse_test:.3f}"
    ]
    #
    featureWeights = pd.DataFrame(
                            {'predictor': list(X.columns),
                             'importancia': model.feature_importances_}
                            )
    #
    #saving results
    fileName = f"{label}.txt"
    with open(fileName, "w") as modelScoreTxt:
        for message in resultsLog:
            modelScoreTxt.write(message)
            print(message)
    #
    featureWeights.sort_values('importancia', ascending=False)
    print(featureWeights.sort_values('importancia', ascending=False))
    #
    return modelScore_train,modelScore_test,R2_train,R2_test,mea_train,mea_test,rmse_train,rmse_test,featureWeights
# 
# 
# #
##################################################################################
##################################################################################
def scoringTestLifeCycle(model,predictions_lifeCycle,  y_lifeCycle,label): 
    # R^2 Pearson's coefficient
    R2_test = r2_score(predictions_lifeCycle, y_lifeCycle)
    modelScore_test = model.score(X_lifeCycle, y_lifeCycle)
    mea_test  = mean_absolute_error(predictions_lifeCycle, y_lifeCycle)
    rmse_test  = np.sqrt(mean_squared_error(predictions_lifeCycle, y_lifeCycle))
    #
    resultsLog = [
    f"Scoring results for model {label}",
    f"model: {model}",
    f"number of sampples: {n_samples}",
    f"R2 in testing stage: {modelScore_test:.3f}",
    f"Pearson's coefficient in testing stage: {R2_test:.3f}",
    f"Mean absolute error in testing stage: {mea_test:.3f}",
    f"Root mean square error in testing stage: {rmse_test:.3f}"
    ]
    #saving results
    fileName = f"{label}.txt"
    with open(fileName, "w") as modelScoreTxt:
        for message in resultsLog:
            modelScoreTxt.write(message)
            print(message)
    #
    return modelScore_test,R2_test,mea_test,rmse_test
# 
# 
# #
##################################################################################
##################################################################################
def colNames(label,numberOfLines,flg):
    testingFeature                                   = label
    testingFeature_windHeading                       = f"{testingFeature}_WindHead_[degrees]"
    if(flg < 1):
        testingFeature_windSpeed                         = f"{testingFeature}_WindStSpeed_[m_s]"
        testingFeature_squareWindSpeed                   = f"{testingFeature}_SquareWindStSpeed_[m_s]^2"
    else:
        testingFeature_windSpeed                         = f"{testingFeature}_WindStSpeed_[m/s]"
        testingFeature_squareWindSpeed                   = f"{testingFeature}_SquareWindStSpeed_[m/s]^2"        
    testingFeature_timeStep                          = f"{testingFeature}_timeStep"
    testingFeature_mooring_system_mean_total_tension = f"{testingFeature}_mooring_system_mean_total_tension"
    testingFeature_mooring_system_max_total_tension  = f"{testingFeature}_mooring_system_max_total_tension"
    testingFeature_mooring_line_max_tension          = f"{testingFeature}_mooring_line_max_tension"
    testingFeature_mooring_line_max_tension_id       = f"{testingFeature}_mooring_line_max_tension_id"
    #
    # adding extra columns for tracking the max tensions in each line
    testingFeature_mooring_line_vec_mean_tension    = [ f"{testingFeature}_mooring_line_{kk}_mean_tension" for kk in range(numberOfLines) ]
    testingFeature_mooring_line_vec_max_tension     = [ f"{testingFeature}_mooring_line_{kk}_max_tension" for kk in range(numberOfLines) ]
    #
    testingFeature_mean_surge                       = f"{testingFeature}_mean_surge"
    testingFeature_max_surge                        = f"{testingFeature}_max_surge"
    testingFeature_max_surge_id                     = f"{testingFeature}_max_surge_id"
    testingFeature_mean_sway                        = f"{testingFeature}_mean_sway"
    testingFeature_max_sway                         = f"{testingFeature}_max_sway"
    testingFeature_max_sway_id                      = f"{testingFeature}_max_sway_id"
    testingFeature_mean_yaw                         = f"{testingFeature}_mean_yaw"
    testingFeature_max_yaw                          = f"{testingFeature}_max_yaw"
    testingFeature_max_yaw_id                       = f"{testingFeature}_max_yaw_id"
    testingFeature_min_surge                        = f"{testingFeature}_min_surge"
    testingFeature_min_surge_id                     = f"{testingFeature}_min_surge_id"
    testingFeature_min_sway                         = f"{testingFeature}_min_sway"
    testingFeature_min_sway_id                      = f"{testingFeature}_min_sway_id"
    testingFeature_min_yaw                          = f"{testingFeature}_min_yaw"
    testingFeature_min_yaw_id                       = f"{testingFeature}_min_yaw_id"
    testingFeature_describe                         = f"{testingFeature}_describe"
    #
    testingFeature_id                               = f"{testingFeature}_id" # index of case items contained in each parent folder
    df_cols_Features   = [testingFeature_id,testingFeature_windSpeed,testingFeature_squareWindSpeed,testingFeature_windHeading]
    df_cols_maxTarget  = [testingFeature_max_surge,testingFeature_min_surge,testingFeature_max_sway,testingFeature_min_sway,testingFeature_max_yaw,testingFeature_min_yaw,testingFeature_mooring_system_max_total_tension]
    df_cols_meanTarget = [testingFeature_mean_surge,testingFeature_mean_sway,testingFeature_mean_yaw,testingFeature_mooring_system_mean_total_tension]
    for kk in range(numberOfLines):
        df_cols_meanTarget.append(testingFeature_mooring_line_vec_mean_tension[kk])
        df_cols_maxTarget.append(testingFeature_mooring_line_vec_max_tension[kk])
    
    return df_cols_Features,df_cols_maxTarget,df_cols_meanTarget
#
#
# #
##################################################################################
##################################################################################
# 
#
# #
##################################################################################
##################################################################################
##################################################################################
##################################################################################
##################################################################################
###                                                                           ###
###                         FUNCTION DEFINITIONS END                          ###
###                                                                           ###
##################################################################################
#
# 
# 
# 
# 
# 
# #
##################################################################################
###                                                                           ###
###                         MAIN BODY OF THE PROGRAM                          ###
###                                                                           ###
##################################################################################
print("Displaying pickle file with selected features")
print(data)
print(data.info())
print(data.describe())
print(data.head())
print(data.tail())
# 
# 
# 
#
df_cols_Features,df_cols_maxTarget,df_cols_meanTarget   = colNames(testingFeature,numberOfLines,1)
targetColumn = df_cols_maxTarget[targetColumnValue] 
print(targetColumn)
# 
#
print("Checking for NaN values:")
for i in data.columns:
    print(str(i)+ ": " + str(data[i].isnull().sum()))
    #
print("Elimination of NaN values")
data = data.dropna()
data.info()
data.describe()
# 
# 
data["Nivel"] = 0
data["Nivel"][data[targetColumn] >= threshold_force] = 1
print(data["Nivel"])
# 
# 
# Splitting data set
y = data[targetColumn].iloc[0:maxSamples]
#X = data[df_cols_Features]   
#X = data[testingFeature_id,testingFeature_windSpeed,testingFeature_squareWindSpeed,testingFeature_windHeading]
testingFeature_squareWindSpeed = "b_30_years_SquareWindStSpeed_[m_s]^2"
testingFeature_windHeading = "b_30_years_WindHead_[degrees]"
X = data[[testingFeature_squareWindSpeed,testingFeature_windHeading]].iloc[0:maxSamples]
#X = data[[testingFeature_squareWindSpeed]].iloc[0:maxSamples]
n_samples, n_features = X.shape
print(f"Number of samples: {n_samples}")
print(f"Number of features: {n_features}")
# 
# 
# With decisiion trees there is no need to scale the data
#from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=testSize, shuffle=shuffleFlag, random_state=ramdomState)
print(f"Shape feature matrix for training {X_train.shape}")
print(f"Shape feature matrix for testing {X_test.shape}")
print(f"Shape feature matrix for training {y_train.shape}")
print(f"Shape feature matrix for testing {y_test.shape}")
#Por defecto shuffle=True y stratify=None
# 
# 
print("Feature Matrix")
print(X)
print("Target Vector")
print(y_train)
# 
# 
# 
# 
# 
print("Displaying pickle file with all life cycle data")
print(data_lifeCycle)
print(data_lifeCycle.info())
print(data_lifeCycle.describe())
#
testingFeature                                   = label_lifeCycle
#
df_cols_Features_label_lifeCycle,df_cols_maxTarget_label_lifeCycle,df_cols_meanTarget_label_lifeCycle   = colNames(label_lifeCycle,numberOfLines,0)
#print(df_cols_Features_label_lifeCycle)
#print(df_cols_maxTarget_label_lifeCycle)
#print(df_cols_meanTarget_label_lifeCycle)
targetColumn_label_lifeCycle = df_cols_maxTarget_label_lifeCycle[targetColumnValue] #Tensions in mooring line 41
print(targetColumn_label_lifeCycle)
#
y_lifeCycle = data_lifeCycle[targetColumn_label_lifeCycle]
#X = data_lifeCycle[df_cols_Features]   
#X = data_lifeCycle[testingFeature_id,testingFeature_windSpeed,testingFeature_squareWindSpeed,testingFeature_windHeading]
#data_lifeCycle.rename(columns = { "b_30_years_SquareWindStSpeed_[m_s]^2": "b_maxDis_SquareWindStSpeed_[m/s]^2", "b_30_years_WindHead_[degrees]": "b_maxDis_WindHead_[degrees]"},inplace=True) 
print(data_lifeCycle.columns)
X_lifeCycle = data_lifeCycle[[testingFeature_squareWindSpeed,testingFeature_windHeading]]
##X = data_lifeCycle[[testingFeature_squareWindSpeed]]
n_samples, n_features = X_lifeCycle.shape
print(f"Number of samples: {n_samples}")
print(f"Number of features: {n_features}")
#
X_lifeCycle_train, X_lifeCycle_test, y_lifeCycle_train, y_lifeCycle_test = train_test_split(X_lifeCycle , y_lifeCycle , test_size=testSize, shuffle=shuffleFlag, random_state=ramdomState)
print(f"Shape feature matrix for training {X_lifeCycle_train.shape}")
print(f"Shape feature matrix for testing {X_lifeCycle_test.shape}")
print(f"Shape feature matrix for training {y_lifeCycle_train.shape}")
print(f"Shape feature matrix for testing {y_lifeCycle_test.shape}")
# 
# 
# 
# 
# 
print("Plotting error evolution")
#from sklearn.ensemble import RandomForestRegressor
train_error = []
test_error = []
#n_estimators = [10,25,50,100,200,250,300,350,500,1000]
n_estimators = [n for n in range(500,runX+100,10)]

for estimator in n_estimators:
    RF_rgr = RandomForestRegressor(n_estimators = estimator,
                                   #**params,
                                   random_state = 42)
    
    RF_rgr.fit(X_train, y_train)

    train_error.append(RF_rgr.score(X_train, y_train))
    test_error.append(RF_rgr.score(X_test, y_test))
# 
# 
# 
fig, ax = plt.subplots()
ax.plot(n_estimators, train_error, label="Training Stage R2")
ax.plot(n_estimators, test_error, label="Validation Stage R2")
ax.set_ylabel(f"$R^2$")
ax.set_xlabel(f"n_estimators")
plt.minorticks_on()
plt.legend(); 
plt.title(f'$R^2$ Evolution withthe number of estimators',fontsize=10)
#
plt.savefig('rr_maxTensions_predicted_vs_simulated.png')
# 
#Predecimos en train y test
predictions_train = RF_rgr.predict(X_train)
predictions_test = RF_rgr.predict(X_test)
#
modelScore_train,modelScore_test,R2_train,R2_test,mea_train,mea_test,rmse_train,rmse_test,featureWeights = scoringTest(RF_rgr,X_train, y_train,X_test, y_test,f"randomForest_cv{runX}")
plot_ml_regressor_predictionVStarget_values_idSamples(figureSize,f"rr_test_maxTensions",predictions_train, y_train,f"Training_Stage{runX}")
plot_ml_regressor_predictionVStarget_values_idSamples(figureSize,f"rr_test_maxTensions",predictions_test, y_test,f"Validation_Stage{runX}")
plot_ml_regressor_predictionVStarget_values(figureSize,f"rr_test_maxTension{runX}",predictions_train, y_train,predictions_test, y_test)
# 
# 
"""
Life Cycle Assesment
"""
predictions_lifeCycle = RF_rgr.predict(X_lifeCycle);predictions_train = RF_rgr.predict(X_train)
# R^2 Pearson's coefficient
modelScore_test,R2_test,mea_test,rmse_test = scoringTestLifeCycle(RF_rgr,predictions_lifeCycle,  y_lifeCycle,f"randomForest_test{runX}")
plot_ml_regressor_predictionVStarget_values_idSamples(figureSize,f"rr_test_maxTensions",predictions_train, y_train,f"Life_Cycle{runX}")
plot_ml_regressor_lifeCycle_predictionVStarget_values(figureSize,f"rr_test_lifeCycle_maxTension{runX}",predictions_lifeCycle, y_lifeCycle)
# 
# 
# 
# Definimos el grid de hiperparámetros a evaluar:
"""
param_grid = {"n_estimators": [1, 5, 10, 20],
              'max_depth':[3, 5, 10], 
              'min_samples_split':[20, 50, 70],
              'min_samples_leaf':[15, 25, 40],
              'max_leaf_nodes':[20, 50, 80]}
"""

# Definimos el grid de hiperparámetros a evaluar:
parameters = {
         #'criterion' : ["squared_error", "absolute_error", "friedman_mse", "poisson"]
         'criterion' : ["squared_error", "absolute_error"],    
         #'criterion': ['gini', 'entropy'],
         #'splitter': ['best', 'random'],
         'max_depth': [n for n in range(500,runX+100,10)],
         'max_features': ['auto', 'sqrt'],
         #'min_samples_leaf': [1, 2, 4],
         #'min_samples_split': [2, 5, 14],
         'min_samples_leaf': [1, 2],
         'min_samples_split': [2, 5],    
         #'min_impurity_decrease' : [0.001,0.005,0.01,0.05,0.1,0.5],
         'min_impurity_decrease' : [0.001,0.01,0.1],    
         'ccp_alpha' : ccpAlphaVec# prunning: complexity penalization parameter 
             }

# Búsqueda de hiperparámetros óptmimos por validación cruzada:
RF_rgr_cv = GridSearchCV(
        estimator = RandomForestRegressor(
            #n_estimators = [10,25,50,100,200,250,300,350,500,1000]
            random_state = 42),
        param_grid = parameters,
        cv         = cv_val,
        return_train_score = True,
        n_jobs = -1,
        )  

RF_rgr_cv.fit(X_train, y_train)


print(RF_rgr_cv.best_params_)
print("-------------------------")
#Coeficiente de determinación
print("R2 en train: %.2f" % RF_rgr_cv.score(X_train, y_train))
print("R2 en test: %.2f" % RF_rgr_cv.score(X_test, y_test))
# 
# 
RF_rgr_cv = RF_rgr_cv.best_estimator_
print(RF_rgr_cv.fit(X_train, y_train))
RF_rgr_cv.fit(X_train, y_train)
#Predecimos en train y test
predictions_train = RF_rgr_cv.predict(X_train)
predictions_test = RF_rgr_cv.predict(X_test)
#
modelScore_train,modelScore_test,R2_train,R2_test,mea_train,mea_test,rmse_train,rmse_test,featureWeights = scoringTest(RF_rgr_cv,X_train, y_train,X_test, y_test,f"randomForest_cv{runX}")
plot_ml_regressor_predictionVStarget_values_idSamples(figureSize,f"rr_CV_maxTensions",predictions_train, y_train,f"Training_Stage{runX}")
plot_ml_regressor_predictionVStarget_values_idSamples(figureSize,f"rr_CV_maxTensions",predictions_test, y_test,f"Validation_Stage{runX}")
plot_ml_regressor_predictionVStarget_values(figureSize,f"rr_CV_maxTension{runX}",predictions_train, y_train,predictions_test, y_test)
# 
# 
"""
Life Cycle
"""
predictions_lifeCycle = RF_rgr.predict(X_lifeCycle)
# R^2 Pearson's coefficient
modelScore_test,R2_test,mea_test,rmse_test = scoringTestLifeCycle(RF_rgr,predictions_lifeCycle,  y_lifeCycle,f"randomForest_CV2")
plot_ml_regressor_predictionVStarget_values_idSamples(figureSize,f"rr_cv2_lifeCycle_maxTensions",predictions_lifeCycle, y_lifeCycle,f"Validation_Stage")
#plot_ml_regressor_predictionVStarget_values(figureSize,f"rr_cv_lifeCycle_maxTension",predictions_train, y_train,predictions_lifeCycle, y_lifeCycle)
plot_ml_regressor_lifeCycle_predictionVStarget_values(figureSize,f"rr_cv2_lifeCycle_maxTension{runX}",predictions_lifeCycle, y_lifeCycle)
# 
# 
# 
# 
# 
# 
# 
# Definimos el grid de hiperparámetros a evaluar:
runX = 1500
# Definimos el grid de hiperparámetros a evaluar:
"""
param_grid = {"n_estimators": [1, 5, 10, 20],
              'max_depth':[3, 5, 10], 
              'min_samples_split':[20, 50, 70],
              'min_samples_leaf':[15, 25, 40],
              'max_leaf_nodes':[20, 50, 80]}
"""

# Definimos el grid de hiperparámetros a evaluar:
parameters = {
         #'criterion' : ["squared_error", "absolute_error", "friedman_mse", "poisson"]
         'criterion' : ["squared_error", "absolute_error"],  
         #'criterion': ['gini', 'entropy'],
         #'splitter': ['best', 'random'],
         'max_depth':  [n for n in range(500,runX+100,100)],
         'max_features': ['auto', 'sqrt'],
         #'min_samples_leaf': [1, 2, 4],
         #'min_samples_split': [2, 5, 14],
         'min_samples_leaf': [1, 2],
         'min_samples_split': [2, 5],
         #'min_impurity_decrease' : [0.001,0.005,0.01,0.05,0.1,0.5],
         'min_impurity_decrease' : [0.01,0.05,0.1],
         'ccp_alpha' : [0.005,0.001,0.005] # [0.001,0.01,0.05] prunning: complexity penalization parameter 
             }


# Búsqueda de hiperparámetros óptmimos por validación cruzada:
RF_rgr_cv_lifeCycle = GridSearchCV(
        estimator = RandomForestRegressor(
            #n_estimators = [10,25,50,100,200,250,300,350,500,1000]
            random_state = 42),
        param_grid = parameters,
        cv         = cv_val,
        return_train_score = True,
        n_jobs = -1,
        )  

RF_rgr_cv_lifeCycle.fit(X_lifeCycle_train, y_lifeCycle_train)


print(RF_rgr_cv_lifeCycle.best_params_)
print("-------------------------")
#Coeficiente de determinación
print("R2 en train: %.2f" % RF_rgr_cv_lifeCycle.score(X_lifeCycle_train,y_lifeCycle_train))
print("R2 en test: %.2f" % RF_rgr_cv_lifeCycle.score(X_lifeCycle_test, y_lifeCycle_test))
# 
# 
#Predecimos en train y test
RF_rgr_cv_lifeCycle = RF_rgr_cv_lifeCycle.best_estimator_
RF_rgr_cv_lifeCycle.fit(X_lifeCycle_train, y_lifeCycle_train)
print(RF_rgr_cv_lifeCycle)
predictions_lifeCycle_train = RF_rgr_cv_lifeCycle.predict(X_lifeCycle_train)
predictions_lifeCycle_test = RF_rgr_cv_lifeCycle.predict(X_lifeCycle_test)
print(f"Shape feature matrix for training {X_lifeCycle_train.shape}")
print(f"Shape feature matrix for training {predictions_lifeCycle_train.shape}")
print(f"Shape feature matrix for testing {X_lifeCycle_train.shape}")
print(f"Shape feature matrix for testing {predictions_lifeCycle_test.shape}")
# 
# 
modelScore_train,modelScore_test,R2_train,R2_test,mea_train,mea_test,rmse_train,rmse_test,featureWeights = scoringTest(RF_rgr_cv_lifeCycle,X_lifeCycle_train, y_lifeCycle_train,X_lifeCycle_test, y_lifeCycle_test,f"randomForest_CV3")
plot_ml_regressor_predictionVStarget_values_idSamples(figureSize,f"rr_CV3_lifeCycle_maxTensions",predictions_lifeCycle_train, y_lifeCycle_train,f"Training_Stage")
plot_ml_regressor_predictionVStarget_values_idSamples(figureSize,f"rr_CV3_rr_CV3_lifeCycle_maxTensions",predictions_lifeCycle_test, y_lifeCycle_test,f"Validation_Stage")
plot_ml_regressor_predictionVStarget_values(figureSize,f"rr_CV3_rr_CV3_lifeCycle_maxTension",predictions_lifeCycle_train, y_lifeCycle_train,predictions_lifeCycle_test, y_lifeCycle_test)
# 
# #