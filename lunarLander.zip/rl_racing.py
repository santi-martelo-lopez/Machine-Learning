#python3 rl_racing.py
"""
Based on the environment the agent takes a certain action a_t

Based on this particular action the agent recieve a reward r_t+1

Because of the reward r_t, the state of the agent will change, s_t+1


"""

#First the environmet class will give random rewards, just to check the class implementation

#import numpy as np
#from typing import List

import enviroment as env
#from enviroment import samepleEnvironment


if __name__ == "__main__":
    env101      = env.samepleEnvironment()
    agent101    = env.agent()
    #
    #time loop
    while not env101.is_done():
        agent101.step_episode(env101)
        print("========= End of episode ========= ")
    #
    print(f"Total reward obtained: {agent101.totalReward:.4f}")