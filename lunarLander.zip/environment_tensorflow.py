import os # for os.mkdir(folder_name)
import numpy as np 
import pandas as pd
from sklearn.model_selection import train_test_split
import tensorflow as tf
from tensorflow.keras.models import Sequential, load_model
from tensorflow.kears.layers import Dense
from sklearn.metrics import accuracy_score

def image_recognition101(X,y):
    #general function for training a neural  network for image recognition
    test_ratio              = 0.2
    hidden_layers           = [3,64,1]
    n_epochs                = 500
    batchSize               = 32
    hidden_activation       = 'relu'
    output_activation       = 'sigmoid'
    op_scheme               = 'sgd'
    loss_scheme             = 'binary_crossentropy'
    accuracy_scheme         = 'accuracy'
    model_name              = 'tf_image_recognition101'
    folder_name             = 'tf_image_recognition'
    model_path              = f'./{folder_name}/{model_name}'
    #
    X_train, X_test, y_train, y_test = train_test_split(X,y, test_size=test_ratio)
    #
    # model architecture
    #from tensorflow.keras.models import Sequential, load_model
    #from tensorflow.kears.layers import Dense
    #from sklearn.metrics import accuracy_score
    #
    model = Sequential()
    model.add(Dense( units= hidden_layers[0], activation = hidden_activation, input_dim = (X.train.columns ) ) )
    model.add(Dense( units= hidden_layers[1], activation = hidden_activation ) ) # try with tanh, leanky_relu
    model.add(Dense( units= hidden_layers[2], activation = output_activation ) ) # softmax???
    model.compile(loss=loss_scheme, optimizer=op_scheme, accuracy=accuracy_scheme)
    #
    # model training
    model.fit(X_train,y_train, epochs=n_epochs, batch_size=batchSize)
    #
    # model testing
    y_hat = model.predict(X_test, y_test)
    y_hat = [0 if val < 0.5 else 1 for val in y_hat]# just get values between 0 and 1
    print(f'Accuracy score is: {accuracy_score(y_test,y_hat)}') 
    #
    #saving model
    os.mkdir(folder_name)
    model.save(model_path)
    # del model # for deleting a model
    #
    #loading model
    model = load_model(model_path)



    class DeepQNetwork(object):
        #With this class we can instantiate 2 networks: 
        #   agent: it selects an action
        #   critict: it tells the value of an action
        # These 2 networks have differnt names, that is why in the constructor, one of the imputs 
        # is the name of the network
        def __init__(self,lr,n_actions,name,fc1_dims=256,input_dims=(210,160,4),check_point_directory='tf_model_atariGame/dqn'):
            # resolution of images
            self.lr                         = lr
            self.n_actions                  = n_actions
            self.name                       = name
            self.fc1_dims                   = fc1_dims
            self.input_dims                 = input_dims
            self.check_point_directory      = check_point_directory
            #
            self.session                    = tf.Session # this instantiates everything as a grapth. Each netwwork needts its own graph
            #
            self.build_network() # we add everything to the grapth
            #
            self.session.run(tf.global_variables_initializer() ) # we initialize everything
            #
            self.saver = tf.train.Saver #for saving the model
            self.check_point_file = os.path.join(self.check_point_directory,'deepQNet.ckpt')
            self.params = tf.get_collection(tf.GrapthKeys.TRAINABLE_VARIABLES,
                                            scope = self.name) # for keeping track of parameters of the self.name net
            
        def build_net(self): #lets define the net architecture
            with tf.variable_scope(self.name):# we will place everything in the scope of the agent's name
                self.input = tf.placeholder(tf.float32,
                                            shape=[None, *self.input_dims], # parameter None allows to train in batches, in this case, batches of stacjed frames 
                                            name = 'inputs') #placeholder for the inputs of self.name object
                self.actions = tf.placeholder(tf.float32,
                                              shape=[None,self.n_actions],
                                              name = 'actions_taken')# this shape is needed for 1 hot encoding of the actions
                self.q_target = tf.placeholder(tf.float32,
                                               shape=[None,self.n_actions])
                #
                # convolutions for image features extraction, https://www.tensorflow.org/api_docs/python/tf/keras/layers/Conv2D
                conv1 = tf.layers.conv2d(inputs = self.input,
                                         filters = 32, # dimensionality of the output space (i.e. the number of output filters in the convolutio
                                         kernel_size = (8,8), # specifying the height and width of the 2D convolution window. 
                                         strides = 4, # specifying the strides of the convolution along the height and width. Can be a single integer to specify the same value for all spatial dimensions. Specifying any stride value != 1 is incompatible with specifying any dilation_rate value != 1.
                                         name = 'conv1',
                                         kernel_initializer = tf.variance_scaling_initializer(scale=2)) # Initializer for the kernel weights matrix (see keras.initializers). Defaults to 'glorot_uniform'.
                                        #tf.variance_scaling_initializer(scale=2) -> deepMind paper
                conv1_activated = tf.nn.relu(conv1) # lets activate the layer with a relu function                
                #
                conv2 = tf.layers.conv2d(inputs = conv1_activated,
                                         filters = 64, 
                                         kernel_size = (4,4),
                                         strides = 2,
                                         kernel_initializer = tf.variance_scaling_initializer(scale=2)) # Initializer for the kernel weights matrix (see keras.initializers). Defaults to 'glorot_uniform'.
                conv2_activated = tf.nn.relu(conv2)
                #
                conv3 = tf.layers.conv2d(inputs = conv2_activated,
                                         filters = 128,
                                         kernel_size = (3,3),
                                         strides = 1,
                                         kernel_initializer = tf.variance_scaling_initializer(scale=2)) # Initializer for the kernel weights matrix (see keras.initializers). Defaults to 'glorot_uniform'.
                conv3_activated = tf.nn.relu(conv3)
                #
                # lets flatten the outputs and put them trough a dense network to get the Q values (values of each state-action pair)
                flattened_data = tf.layers.flatten(conv3_activated)
                dense1 = tf.layers.dense(flattened_data, 
                                         units = self.fc1_dims,
                                         activation = tf.nn.relu,
                                         kernel_initializer = tf.variance_scaling_initializer(scale=2)) # Initializer for the kernel weights matrix (see keras.initializers). Defaults to 'glorot_uniform'.
                #
                # lets define the output: state-action pairs
                self.Q_values = tf.layers.dense(dense1,
                                                units = self.n_actions, # this yields 1 output for each action
                                                kernel_initializer = tf.variance_scaling_initializer(scale=2)) # Initializer for the kernel weights matrix (see keras.initializers). Defaults to 'glorot_uniform'.
                #
                # lets get the actual value of q for each action
                self.q = tf.reduce_sum(tf.multiply(self.Q_values,self.actions))
                #
                # lets define a loss function 
                self.loss = tf.reduce_mean(tf.square( self.q - self.q_target ) ) # mean square difference
                # self.q_target is the maximal action that could be taken
                #
                # lets define the optimizer
                self.train_op = tf.train.AdamOptimizer(self.lr).minimize(self.loss)
                #
            def load_checkpoint(self):# loading saved model
                print(f'Loading saved model...')
                self.saver.restore(self.session,self.check_point_file) # this will load the graph from the saved model
                #
            def save_checkpoint(self):#saving the model
                print('Saving model...')
                self.saver.save(self.session,self.check_point_file)
                #
        #
        # lets define the agent that
        class agent_class(object):
            def __init__(self,
                         alpha, # learning rate
                         gamma, # discount factor of future rewards in Bellman equation
                         memory_size, # how many transitions to store in memory
                         n_actions,
                         epsilon,
                         batch_size,
                         replace_targetNetwork=5000,# how often we want to replace the target network
                         n_input = (210,160,4),
                         q_next = 'tf_model_atariGame/q_next', # where to save q_eval_Network, it yields the value of the action to take
                         q_eval = 'tf_model_atariGame/q_eval'): # where to save q_Network, it yields the action to take
                self.n_actions              = n_actions
                self.action_space           = [ii for ii in range(self.n_actions)] # this will be used to take random actions
                self.gamma                  = gamma
                self.mem_cntr               = 0 # keeps tract of the first available memory for storing the agents memory
                self.memory_size            = memory_size
                self.epsilon                = epsilon
                self.batch_size             = batch_size
                self.replace_targetNetwork  = replace_targetNetwork
                #
                # lets instantiate the q_target network to get the value of the next action
                self.q_next = DeepQNetwork(alpha,
                                           n_actions,
                                           input_dims = n_input,
                                           name='q_next',
                                           check_point_directory = q_next)
                #
                # neetwork to evaluate which action to take
                self.q_eval = DeepQNetwork(alpha,
                                           n_actions,
                                           input_dims = n_input,
                                           name = 'q_eval',
                                           check_point_directory = q_eval) 
                #
                # lets define the memory cache
                self.state_memory       = np.zeros( (self.memory_size, *n_input) )
                self.new_state_memory   = np.zeros( (self.memory_size, *n_input) )
                self.action_memory      = np.zeros( (self.memory_size, self.n_actions),dytpe=np.int8 ) # this will store the 1-hot encoding of the actions
                self.reward_memory      = np.zeros( (self.memory_size) ) 
                self.episode_steps      = np.zeros( (self.memory_size),dtype=np.int32 ) # keeping track of episode steps
                self.episode_end_memory = np.zeros( (self.memory_size),dtype=np.int8 ) 
                #
            def store_transition(self,state1_,action,reward,state2_,episode_steps,done_flag):
                index = self.mem_cntr % self.memory_size
                self.state_memory[index]        = np.array(state1_,dtype = np.float32)
                self.new_state_memory[index,:]  = state2_
                # lets fo one-hot encoding for the actions
                actions_1hot = np.zeros(self.n_actions)
                actions_1hot = 1.0
                self.action_memory[index]       = actions_1hot
                self.reward_memory[index]       = reward
                self.episode_steps[index]       = episode_steps
                self.episode_end_memory[index]     = done_flag # either a 0 or 1
                #
                self.mem_cntr += 1 # we filled a memory space, so we need to increas the memory counter by 1


            def action_selection(self,state):
                randomValue = np.random.dandom() # random sample from [0,1)
                # as epsilon decreases, the agent will tent to choose a greedy action,  that is,
                # the action that has the greatest value of the next state
                if randomValue < self.epsilon:
                    # exploration approach
                    action = np.random.choice(self.action_space)
                else:
                    actions_outputLayer = self.q_eval.session.run(self.q_eval.Q_values,
                                                     feed_dict = {self.q_eval.input: state})
                    action = np.argmax(actions_outputLayer)# getting the maximun action
                return action