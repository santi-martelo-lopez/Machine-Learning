import colorama 
import matplotlib.pyplot as plt
import torch as T
import torch.nn as nn # for the observation we will use linear layers, not convolutional layers
import torch.nn.functional as F # for defineing activation functions
import torch.optim as optim # for suing Adam optimizer
import pickle
#
import pygame
print("Pygame imported!")
#
from typing import List
import numpy as np
import numpy.random as random
import pandas as pd
#
import os
#
random.seed(32) # lets fix the random numbers
#T.seed()
#
#numpy printing options
np.set_printoptions(precision=2)
#numpy.set_printoptions(suppress=True)
"""

The environment class
Model of the world external to the agent. It provides states and regards to the agents

The enviroment should be capabl of handling actions recieved by the agent. This is done by the action method of environmet
that checks (policy rules such mas max time left or number of episodes left) the number of steps left and returns a reward

__init__ constructor is called to set the number of episodes of the event

get_observation() method returns the current environment observation to the agent

get_actions() returns 0 or 1 corresponding to the 2 available actions (turn left, turn right)

is_done checks the end of the episode
"""
class samepleEnvironment:
    def __init__(self,numSteps = 20):
        self.stepsLeft = numSteps
        print(f"Environment object created")


    def get_observation(self) -> List[float]:
        self.defaultState = [0.0,0.0,0.0]
        # we need to return some logic that gives info about the environment
        return self.defaultState
    
    def get_actions(self)  -> List[int]:
        self.defaultAction = [0,1]
        return self.defaultAction
    
    def is_done(self) -> np.bool_:
        return self.stepsLeft == 0
    

    def action(self, action : int) -> float:
        # we recieve an action
        # we predict with a lookup table /  simulation the results
        # based on the results we return a reward
        if self.is_done():
            raise Exception("Game Over")
        self.stepsLeft -= 1
        print(f"#{self.stepsLeft} episodes left")
        return random.random()
    


    """
The agent class

Task (5 bullet points): 
    specifc  goal: reach way-point omega starting from point alpha obtainig as much reward as possible
    clearly defined: handle rudder , weight distribution and sail orientation
    rules : Policy. algorithm that takes the state of the world as input and ouputs an action

        1. we initialize weights randomly

        2. pre-train with superrvised learning (we can skip this part)

        3. refine policy with reinforced learning

        4. Use PPO 
        
            PPO is classified as a policy gradient method for training an agent’s policy network. The policy network is the function that 
            the agent uses to make decisions. Essentially, to train the right policy network, PPO takes a small policy update (step size), 
            so the agent can reliably reach the optimal solution. A too-big step may direct policy in the false direction, thus having little 
            possibility of recovery; a too-small step lowers overall efficiency. Consequently, PPO implements a clip function that constrains 
            the policy update of an agent from being too large or too small.[ T. Simonini, “Proximal Policy Optimization (PPO),” Hugging Face – The AI community building the future., https://huggingface.co/blog/deep-rl-ppo .] ,
            https://en.wikipedia.org/wiki/Proximal_Policy_Optimization

            
            we can search the most promising option, opt1, and then predict the outcome of opt1 to improve the policy in a certain step

            for unseen options we can train a neural networks policy using the simulations

        Input:
            vehicle position    ->  (x,y)
                    speed,      ->  (u,v)
                    ...         ->  ...
                    picture (with velocity info inferd from previos frames)

                    the network can use a sigmoid / tanh, ... as activation function

        Output y:
            #If the result is larger than 0.5, we will turn the rudder to starboad
            y > 0.7 - > port stardboard 
            0.3 < y < 0.7 -> do not turn
            y < 0.3 - > port turn 

            
        We can reward / penalize later actions more


        The network tries to minimize the error function (landscape, with gradian descent, SGD, Adam, ... we can get stuck in local mina)
            we need to explore a wider range of policies to find the best one (introducing random choice??)

Tries to gain regards by doing actions. 

Constructor
    Initially sets the total reward to 0

Sept_function
accepts environment instance as an argument
Methods that perfroms a range of actions on the environment:
    Observe the environment
    Make a decision about the action based on the observations provided by the environment 
    Submit the action to the environment
    get the reward for the current step

"""
class agent:
    def __init__(self):
        self.totalReward = 0.0
        print(f"Agent object created")

    def step_episode(self, env1 : samepleEnvironment):
        self.oldReward = self.totalReward
        currentObs = env1.get_observation() # lets get the location, speed, ...
        print(f"Current Observation: {currentObs}")
        actionList = env1.get_actions() # lets get possible actions
        print(f"List of possible actions: {actionList}")
        #
        # lets try to get an informed decision, for example using a LSTM network
        defaulChoice = random.choice(actionList) 
        print(f"Action selected: {defaulChoice}")
        #
        # lets check what reward we obtain based
        reward = env1.action(defaulChoice)
        #
        #we update the reward
        self.totalReward += reward
        print(f"Total reward obtained: {self.totalReward:.4f}")
        print(f"Reward increment obtained: {self.totalReward-self.oldReward:.4f}")




class LinearDeepQReplayNetwork(nn.Module):
    # This is the replay network, wich is almost always required
    #
    #def __init__(self,learning_rate=0.9,input_dims=np.arange(8),fc1_dims=10,fc2_dims=8,n_actions=4):
    #def __init__(self,learning_rate=0.9,input_dims=8,fc1_dims=10,fc2_dims=8,n_actions=4):
    def __init__(self,learning_rate,input_dims,fc1_dims,fc2_dims,n_actions):
        # a DeepQ network is an estimate of the value of each action, ginven some environmental states
        """
        learning_rate: learning rate
        input_dims: number of inputs / observation vector
        fc1_dims: number of hidden neurons in the firls layer
        fc2_dims: number of hidden neurons in the firls layer
        n_actions: number of possible actions to select (classification problem?)
        """
        super().__init__()
        #super(LinearDeepQReplayNetwork,self).__init__()
        self.input_dims = input_dims
        self.fc1_dims = fc1_dims
        self.fc2_dims = fc2_dims
        self.n_actions = n_actions
        #
        #lets create some layers
        self.fc1 =  nn.Linear(self.input_dims,self.fc1_dims)
        #self.fc1 =  nn.Linear(*self.input_dims,self.fc1_dims) #check123
        # with * we unpack a list, we pass the elemets of the observation vector
        # this will facialitate the  creation of convolutional networks, or an environment that has 2 dimentional matrix as input
        #
        self.fc2 =  nn.Linear(fc1_dims,self.fc2_dims)
        self.fc3 =  nn.Linear(fc2_dims,self.n_actions) # a DeepQ network is an estimate of the value of each action, ginven some environmental states
        #
        # lets define the optimizer
        self.optimizer = optim.Adam(self.parameters(),lr = learning_rate)
        #
        # lets define the Loss function
        self.loss = nn.MSELoss()
        #
        #lets selct a device
        self.device = T.device('cuda:0' if T.cuda.is_available() else 'cpu')
        #
        # lets send the network to the device
        self.to(self.device)
        #
        print(f"Replay Network Created")
    #
    #lets define the forward pass
    def forward(self,state):
        x = F.relu(self.fc1(state))
        x = F.relu(self.fc2(x))
        self.action_chosen = self.fc3(x)
        # we do not want to activate (use Relu) the action because we want the agents to get the raw estimate 
        return self.action_chosen



class LinearDeepQTargetNetwork(nn.Module):
    # this is the Target network
    pass



class agentLunarLander():
    # What the agent wants to know for the temporal difference update rule policyis
    #   current state, next state, reward recieved, action it took to receirve such reward
    # DeepQ Learning is a model-free bootstraped all policy learning method, so it does not care about the dynamics of the environmet,
    # it would figure out those dynamics by itelf (model-free). It constructs estimated of action value functions, 
    # this is the weight of each action give a certain state, using one stimate to build another estimate (boottrap)
    # all policy means that it has a policy (epsilon ration) to generate reandom actions
    #
    #def __init__(self,gamma=0.7,epsilon=0.9,learningRatio=0.8,input_size = 2,batch_size=10,num_actions=4,
    #             max_memori_size=100_000,epsilon_end = 0.01,epsilon_delta = 5e-4):
    def __init__(self,gamma,epsilon,learningRatio,input_size,batch_size,num_actions,
                 max_memori_size=100_000,epsilon_end = 0.01,epsilon_delta = 5e-4):
        #gamma: determines the weights of future rewards
        #epsilon: exploit - explore rate
        #learningRatio of the DeepQ Replay Network
        # batch_size: after certain number of memories (batch_size) the network parameter will by updated using Adam
        # input_size : state for location, orientation, rudder / wheel angle, main sheep angle/ floorin pedal angle 
        #num_actions : number of possible actions: turn rudder / steering wheel, go faster / slower / recover / loose main sheet 
        #epsilon_end : percentage of the time we take the exploration approach
        #epsilon_delta: decrement in epsilon after each time step (linear approach) 
        #   After some time of acting randomly epsilonit will decay overtime
        self.gamma          = gamma
        self.epsilon        = epsilon
        self.learningRatio  = learningRatio
        self.batch_size     = batch_size
        self.n_actions      = num_actions
        self.memory_size    = max_memori_size
        self.epsilon_min     = epsilon_end
        self.eps_delta      = epsilon_delta
        #
        self.action_space   = [ii for ii in range(num_actions)] 
        # this list comprehensions gives a representation of the available actions
        # this is used in the action selection greedy algorithm
        #
        self.mem_cntr = 0
        # keeps tract of the first available memory for storing the agents memory
        #
        #lets define an object to predict future Q values / best action weights
        # this is the policy network
        self.Q_eval = LinearDeepQReplayNetwork(self.learningRatio,input_dims=input_size,fc1_dims=256,fc2_dims=256,n_actions=self.n_actions)
        #
        # lets define the target / critic network
        self.target_net = LinearDeepQReplayNetwork(self.learningRatio,input_dims=input_size,fc1_dims=256,fc2_dims=256,n_actions=self.n_actions)        
        # at the beginning lets make that the traget network has the same weights than the Q-network
        self.target_net.load_state_dict(self.Q_eval.state_dict() )
        #
        # based on Q valuues, we select a certain action
        # can we fine-tune this using a model of lunar lander, car, sail boat???
        #
        # lets define memory arrays. 
        #self.state_memory = np.zeros((self.memory_size,*input_size),dtype=np.float32) # for keep track of previous states
        #check123
        #self.previous_state_memory = np.zeros((self.memory_size,*input_size),dtype=np.float32) # for state comparison
        #check123
        self.state_memory = np.zeros((self.memory_size,input_size),dtype=np.float32) # for keep track of previous states
        self.new_state_memory = np.zeros((self.memory_size,input_size),dtype=np.float32) # for state new states
        self.action_memory = np.zeros(self.memory_size,dtype=np.int32) # for keeping track of previous actions
        # np.int8
        self.reward_memory = np.zeros(self.memory_size,dtype=np.float32) # for keeping track of previous rewards
        self.episode_steps = np.zeros(self.memory_size,dtype=np.int32) # for keeping track of number of transitions
        # np.int12
        self.terminal_memory = np.zeros(self.memory_size,dtype=np.bool_) # for keeping track of previous atttemps / games
        #
        print("Agent for the Lunar Lander Game Created")
        #print(self.memory_size,input_size,np.shape(self.state_memory))
        #
    def store_transition(self,state1_, action,reward,state2_,done):
        # method for storing past experience
        #
        index = self.mem_cntr % self.memory_size
        self.state_memory[index] = np.array(state1_,dtype = np.float32)
        self.new_state_memory[index,:] = state2_
        self.action_memory[index] = action
        self.reward_memory[index] = reward
        self.terminal_memory[index] = done # either a 0 or 1
        #
        self.mem_cntr += 1 # we filled a memory space, so we need to increas the memory counter by 1
    def store_transition(self,state1_, action,reward,state2_,episode_steps,done):
        # method for storing past experience
        #
        index = self.mem_cntr % self.memory_size
        self.state_memory[index] = np.array(state1_,dtype = np.float32)
        self.new_state_memory[index,:] = state2_
        self.action_memory[index] = action
        self.reward_memory[index] = reward
        self.episode_steps[index] = episode_steps
        self.terminal_memory[index] = done # either a 0 or 1
        #
        self.mem_cntr += 1 # we filled a memory space, so we need to increas the memory counter by 1
        #
    def folder_setup(self,parentFolder="game101"):
        #generation of folder for saving results
        try:
            os.mkdir(parentFolder)
            self.path_max_score = f"./{parentFolder}/max_score"
            os.mkdir(self.path_max_score)
            self.path_max_avg_score = f"./{parentFolder}/max_avg_score"
            os.mkdir(self.path_max_avg_score)
            self.path_final_score = f"./{parentFolder}/final_score"
            os.mkdir(self.path_final_score)
            self.path_freq = f"./{parentFolder}/freq"
            os.mkdir(self.path_freq) 
            self.path_stats = f"./{parentFolder}/stats"
            os.mkdir(self.path_stats)
        except FileExistsError:
            newFolder = f"game_{str(np.random.randint(100))}"
            print(f"Folders aready created, changing parent folder to a random name: {newFolder}")
            self.folder_setup(newFolder)
        except:
            print("Unknown error")
        #
    def save_state(self,message,path):
        #saving state of the agent and replay network
        T.save(self.Q_eval.state_dict(),f"{path}/Q_eval_stateDict_{message}.pt")
        #model = agentLunarLander(*args, **kwargs)
        #model.load_state_dict(T.load(f"{path}/Q_eval_stateDict_{message}.pt"))
        #model.eval() # you must call model.eval() to set dropout and batch normalization layers to evaluation mode before running inference. Failing to do this will yield inconsistent inference results.
        T.save(self.Q_eval,f"{path}/Q_eval_{message}.pt")
        #model = T.load(f"{path}/Q_eval_stateDict_{message}.pt")
        #model.eval() # you must call model.eval() to set dropout and batch normalization layers to evaluation mode before running inference. Failing to do this will yield inconsistent inference results.
        #
        #https://stackoverflow.com/questions/4529815/saving-an-object-data-persistence
        with open(f'{path}/Q_eval_{message}.pkl', 'wb') as outp:
            pickle.dump(self.Q_eval, outp, pickle.HIGHEST_PROTOCOL)
        with open(f'{path}/Q_eval_{message}.pkl', 'rb') as inp:
            self.Q_eval_2 = pickle.load(inp)
        with open(f'{path}/model_lunarLander_{message}.pkl', 'wb') as outp:
            pickle.dump(self, outp, pickle.HIGHEST_PROTOCOL)
            print(f"Checking saved model {self.mem_cntr}")  
        with open(f'{path}/model_lunarLander_{message}.pkl', 'rb') as inp:
            agent_LunarLanderGame102 = pickle.load(inp)
            print(f"Checking loaded model {agent_LunarLanderGame102.mem_cntr}")  

        dict1 = {'x1':self.state_memory[:,0],
                 'y1':self.state_memory[:,1],
                 'u1':self.state_memory[:,2],
                 'v1':self.state_memory[:,3],
                 'lu1':self.state_memory[:,4],
                 'lv1':self.state_memory[:,5],
                 'lef_leg1':self.state_memory[:,6],
                 'right_leg1':self.state_memory[:,7],
                 'x2':self.new_state_memory[:,0],
                 'y2':self.new_state_memory[:,1],
                 'u2':self.new_state_memory[:,2],
                 'v2':self.new_state_memory[:,3],
                 'lu2':self.new_state_memory[:,4],
                 'lv2':self.new_state_memory[:,5],
                 'lef_leg2':self.new_state_memory[:,6],
                 'right_leg2':self.new_state_memory[:,7],                 
                 'Actions_do_nothing':self.action_memory[0],
                 'Actions_fire_left_eng':self.action_memory[1],
                 'Actions_fire_main_eng':self.action_memory[2],
                 'Actions_fire_right_eng':self.action_memory[3],
                 'Rewards':self.reward_memory,
                 'Number_of_steps' : self.episode_steps,
                 'Finish_Flag':self.terminal_memory
                       }
        df = pd.DataFrame( dict1 )
        #df.to_csv(f"model_lunarLander_telemetry_{message}.csv", sep='\t', encoding='utf-8',index=False)
        df.to_csv(f"{path}/model_lunarLander_telemetry_{message}.csv", sep=';', encoding='utf-8',index=False)
        #
    def action_selection(self,observation):
        #
        #method for chosing actions
        # observation : environmental state
        #
        if np.random.random() > self.epsilon: # np.random.random() -> random sample from [0,1)
            # exploitations approach, we estimate the weights of the best known actions
            # as epsilon decreases, the agent will tent to choose a greedy action,  that is,
            # the action that has the greatest value of the next state

            #
            #we convert the observations into a torch tensor (state matrix usable by the forward method of the replay network)
            #and we senf this to the device, we need to send the variales on which we want to make computations onto the computing device
            state = T.tensor([observation]).to(self.Q_eval.device) # the network is set up in a way in which we need to use [] in [observation]
            #check123
            #
            actions_raw_vals = self.Q_eval.forward(state) #action weights
            #lets select the action with the largest weight
            action = T.argmax(actions_raw_vals).item() #without .item() we get a tensor
            #
        else:
            # exploration approach
            action = np.random.choice(self.action_space)
        #
        return action
    #
    #
    #Method where the agent learns from pasts experiences
    def learn(self):
        #We need to olve the dilema of how we learn from pasts memories
        # we can play randomly to acquire a baseline for a while and then we start learning
        if self.mem_cntr < self.batch_size:
            return
        #
        #print(f"Learning Phase, couner value# {self.mem_cntr}")
        # or we can start learning rightaway:
        self.Q_eval.optimizer.zero_grad() # Resets the gradients of all optimized torch.Tensor s.
        #
        # lets calculate the position of the maximum memory, we just want to select until the last filled memory slot
        # we take the minimum value of:
        #print(f"self.mem_cntr {self.mem_cntr}")
        #print(f"self.memory_size {self.memory_size}")
        max_memory = min(self.mem_cntr,self.memory_size)
        #print(f"max_memory {max_memory}")
        #
        # lets create a batch of memories to train
        batch = np.random.choice(max_memory,self.batch_size,replace=False)# replace = False -> this way we avoid selecting the same memory more than once
        #print(F"batch {batch}")
        #This way, once we select a memoy we take it out of the pool of available memories
        # batch is an array of indexes, of size batch_size, randomly slected for this array: [0,1,3,...,max_memory-1]
        #
        # we need batch_index and action_index to perform a proper array slicing 
        batch_index = np.arange(self.batch_size,dtype=np.int32) #[0,1,...,self.batch_size-1]
        #print(f"batch_index {batch_index}")
        #
        # using the list of random indexes in batch, lets select some memories
        #lets convert a numpy arrray subset of the agent memories into torch tensor and sen it to the device
        state_batch = T.tensor(self.state_memory[batch]).to(self.Q_eval.device)
        #print(f"state_batch {state_batch}")
        #
        #lets do the same for new states, rewwards and terminated atemps
        new_state_batch = T.tensor(self.new_state_memory[batch]).to(self.Q_eval.device)
        reward_batch = T.tensor(self.reward_memory[batch]).to(self.Q_eval.device)
        n_episodes_batch = T.tensor(self.episode_steps[batch]).to(self.Q_eval.device)#check123
        terminal_batch = T.tensor(self.terminal_memory[batch]).to(self.Q_eval.device)
        #
        action_batch = self.action_memory[batch]
        #
        #feedforward for getting values to use in the loss function. We are passing an array of memories, and for each memory we 
        #forecast which action is the best based of its forecasted weight. So we end up geting a matrix as a results so we need to estact
        # using [batch_index,action_batch]
        q_eval = self.Q_eval.forward(state_batch)[batch_index,action_batch] # we extract the values of the actions we actually took
        #print(f"q_eval {q_eval}")
        #
        #check123
        #q_next = self.Q_eval.forward(new_state_batch)# instead of this we can use a target network
        with T.no_grad():
            q_next = self.target_net.forward(new_state_batch)
        #print(f"q_next {q_next}")
        q_next[terminal_batch] = 0.0
        #print(f"q_next {q_next}")
        #print(f"reward_batch {reward_batch}")
        #print(f"self.gamma {self.gamma}")
        #
        #lets compute new q values with a greedy aproax (we use max() ) using info from q_next (future q values)
        q_target = reward_batch + self.gamma * T.max(q_next,dim = 1)[0] # this max retunrs the value and the index, we only need the value
        #dims = 1 -> we perform the max opteration along the rows / action dimension
        #
        #lets comute the loss function
        # we send all info to the device
        loss = self.Q_eval.loss(q_target,q_eval).to(self.Q_eval.device)
        #
        #next we comupte the back propagation steps
        loss.backward()
        #
        #check123
        # In-place gradient clipping
        #max_value = 100 # To prevent exploding gradients
        #T.nn.utils.clip_grad_value(self.Q_eval.parameters(),max_value)#check123
        """ https://saturncloud.io/blog/how-to-do-gradient-clipping-in-pytorch/
        During training, we use the clip_grad_norm_ function to clip the gradients of the neural network parameters to 
        a maximum norm of 1.0. This ensures that the gradients are scaled down to a reasonable size, preventing exploding 
        gradients.
        Choosing the Maximum Gradient Norm Value
        The maximum gradient norm value that you use for gradient clipping depends on the specific model and dataset that 
        you’re working with. In general, you should choose a value that is large enough to allow the model to learn quickly, 
        but small enough to prevent exploding gradients.
        A good starting point for the maximum gradient norm value is 1.0, as shown in the example above. You can experiment 
        with different values to see what works best for your model and dataset.
        """
        # we update replay network weights
        self.Q_eval.optimizer.step()
        #
        #filally we decrease the value of the exploration ratio
        self.epsilon = self.epsilon - self.eps_delta if self.epsilon > self.epsilon_min else self.epsilon_min








def plot_learning_curve_pga(scores, fileName, x=None, window=5):
    # for policy gradient algorithm -> pga
    N = len(scores)
    running_avg = np.empty(N)
    for t in range(N):
        running_avg[t] = np.mean(scores[max(0,t-window):(t+1)])
    if x is None:
        x = [ii for ii in range(N)]
    plt.ylabel('score')
    plt.xlabel('Game')
    plt.plot(x,running_avg)
    plt.savefig(fileName)
    plt.show()


def plot_learning_curve_ap(x,scores,epsilons,fileName,lines=None,window=20):
    # for all plicy -> ap
    fig = plt.figure()
    ax = fig.add_subplot(111, label="1")
    ax2 = fig.add_subplot(111, label="2", frame_on=False)
    #
    ax.plot(x,epsilons,color="C0")
    ax.set_xlabel("Training Episodes",color="C0")
    ax.set_ylabel("Epsilon",color="C0")
    ax.tick_params(axis='x',colors="C0")
    ax.tick_params(axis='y',colors="C0")
    #
    N = len(scores)
    running_avg = np.empty(N)
    for t in range(N):
        running_avg[t] = np.mean(scores[max(0,t-window):(t+1)])
    #
    ax2.scatter(x,running_avg,color="C1")
    ax2.get_xaxis().set_visible(False)
    ax2.yaxis.tick_right()
    ax2.set_ylabel('Avegare Score',color="C1")
    ax2.yaxis.set_label_position('right')
    ax2.tick_params(axis='y',colors="C1")
    plt.savefig(fileName)
    plt.show()


def plot_learning_curve_totalScore_steps(x,scores,n_steps,fileName,lines=None,window=20):
    # for all plicy -> ap
    fig = plt.figure()
    ax = fig.add_subplot(111, label="1")
    ax2 = fig.add_subplot(111, label="2", frame_on=False)
    #
    ax.plot(x,n_steps,color="C0")
    ax.set_xlabel("Training Episodes",color="C0")
    ax.set_ylabel("Transition Sptes",color="C0")
    ax.tick_params(axis='x',colors="C0")
    ax.tick_params(axis='y',colors="C0")
    #
    #
    ax2.scatter(x,scores,color="C1")
    ax2.get_xaxis().set_visible(False)
    ax2.yaxis.tick_right()
    ax2.set_ylabel('Total Score',color="C1")
    ax2.yaxis.set_label_position('right')
    ax2.tick_params(axis='y',colors="C1")
    plt.savefig(fileName)
    plt.show()


def categoricalFeaturesExtraction(df,catCol):
    # catCol : list of categorical features
    x_cat = np.stack( [ df[col].cat.codes.values for col in catCol ], 1 )    

def continuousFeaturesExtraction(df,catCol,y_col):
    # catCol : list of categorical features
    cont_cols = [col for col in df.columns if col not in catCol+y_col ]
    #x_con = np.stack( [ df[col].cat.codes.values for col in df.columns if col not in catCol+y_col ], 1 )    

def validation_clasification(y_val,y_test)->None:
    rows = len(y_val)
    correct = 0
    print(f'{"MODEL OUTPUT":26} ARGMAX  Y_TEST')
    for i in range(rows):
        print(f'{str(y_val[i]):26} {y_val[i].argmax():^7}{y_test[i]:^7}')
        if y_val[i].argmax().item() == y_test[i]:
            correct += 1
    print(f'\n{correct} out of {rows} = {100*correct/rows:.2f}% correct')

class TabularModel(nn.Module):
    #tabular network for regression (n_out=1) and classification (n_out>=2)
    def __init__(self,embeding_sizes,n_cont,n_out,layers,p=0.4):
        self.embeds         = nn.ModuleList([nn.Embedding(ni,nf) for ni,nf in embeding_sizes]) # creating a ModuleList object made up of embeddings
        #A simple lookup table that stores embeddings of a fixed dictionary and size.
        #This module is often used to store word embeddings and retrieve them using indices. The input to the module is a list of indices, and the output is the corresponding word embeddings.
        self.embeds_dro     = nn.Dropout(p) # creating a random filter
        self.bn_cont        = nn.BatchNorm1d(n_cont) # creating a normaliztion filter
        layerList           = []
        n_embedings         = sum((nf for ni,nf in embeding_sizes)) # number of categorical inputs
        n_in                = n_embedings + n_cont # n_cont number of continuous inputs
        for ii in layers: #filling intpu and hidden output layers
            layerList.append(nn.Linear(n_in,n_cont))
            layerList.append(nn.RelU(inplace=True))
            layerList.append(nn.BatchNorm1d(ii))
            layerList.append(nn.Dropout(p))
            n_in = ii
        layerList.append(nn.Linear(layers[-1],n_out)) #filling output layer 
        self.layers = nn.Sequential(*layerList) # creating layers
    #
    def forward(self,x_cat,x_cont): #x_cat : categorical features, x_cont : continuous features
        embedings = []
        for ii , ee in enumerate(self.embeds):
            embedings.append(ee(x_cat[:,ii])) # creating a list of embdings
        x = T.cat(embedings, 1) # concatenating ambedings
        x = self.embeds_dro(x) # artifical random filetering, like in biological neurons
        x_cont = self.bn_cont(x)# Normalizing contimuous features
        x = T.cat([x,x_cont], 1) # concatenating filetered categorical and continuous features
        return self.layers(x) # output of the forward pass
    


def pr_bar(progress,total, color = colorama.Fore.YELLOW):
    barLen = 80
    percentage = barLen * progress/float(total) # total may be an integer
    bar = '*'*int(percentage) +'-'*(barLen-int(percentage))
    print(color+f"\r|{bar}| {percentage/float(barLen)*100:.2f}%",end="\r")