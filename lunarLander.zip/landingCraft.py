#python3 landingCraft.py
"""
Based on the environment the agent takes a certain action a_t

Based on this particular action the agent recieve a reward r_t+1

Because of the reward r_t, the state of the agent will change, s_t+1


"""

#First the environmet class will give random rewards, just to check the class implementation



import numpy as np
#from typing import List

import enviroment as env
#from enviroment import samepleEnvironment
import gym # environmet class for 


def main_racingCar():


    env101          = env.samepleEnvironment()
    agent101        = env.agent()
    #
    #time loop
    while not env101.is_done():
        agent101.step_episode(env101)
        print("========= End of episode ========= ")
    #
    print(f"Total reward obtained: {agent101.totalReward:.4f}")


def main_lunarLander():
    #
    #Hyperparameter definition
    Gamma           = 0.99 #update ratio for Q values
    Epsilon         = 1 # this way the agent takes random values at the beggining 
    Batch_size      = 64
    Learning_ratio  = 0.003
    Input_size      = 8 #[8]
    Num_actions     = 4 #do nothing, fire left orientation engine, fire main engine, fire right orientation engine.
    Max_memori_size = 100_000
    Epsilon_end     = 0.01
    Epsilon_delta   = 5e-4
    avg             = 100 #number of samples to compute average score
    #
    # variable for keepin track of reward scores and episodes
    scores = []
    epsides_history = []
    #
    #lets define for how long does the agent need to learn
    n_games = 500
    #
    #
    #https://www.gymlibrary.dev/environments/box2d/lunar_lander/
    lunarEnvironment101 = gym.make('LunarLander-v2')
    #lunarEnvironment101 = gym.make(
    #"LunarLander-v2",
    #continuous = False,
    #gravity = -10.0,
    #enable_wind = False,
    #wind_power = 15.0,
    #turbulence_power = 1.5)
    #replayNetwork_LunarLanderGame   = env.LinearDeepQReplayNetwork()
    agent_LunarLanderGame101           = env.agentLunarLander(gamma=Gamma,
                                                           epsilon=Epsilon,
                                                           learningRatio=Learning_ratio,
                                                           input_size=Input_size,
                                                           batch_size=Batch_size,
                                                           num_actions=Num_actions,
                                                           max_memori_size=Max_memori_size,
                                                           epsilon_end=Epsilon_end,
                                                           epsilon_delta=Epsilon_delta)
    #   
    #episode loop
    for ii in range(n_games):
        # at the top of each new game we set the score, finish flag and observations
        score           = 0
        avg_score       = 0
        max_score       = 0 
        max_avg_score   = 0
        done_flag       = False
        resetVal        = lunarEnvironment101.reset()
        #resetVal = list(resetVal)
        #print(resetVal)
        #
        """
        The state is an 8-dimensional vector: the coordinates of the lander in `x` & `y`, its linear
        velocities in `x` & `y`, its angle, its angular velocity, and two booleans
        that represent whether each leg is in contact with the ground or not.
        """
        observation1 = np.zeros(Input_size,dtype=np.float32)
        mu, sigma = 1, 0 # mean and standard deviation
        #s = np.random.normal(mu, sigma, size=1000)
        observation1[0] = np.random.normal(mu,sigma)
        observation1[1] = np.random.normal(mu,sigma)
        observation1[2] = np.random.normal(mu/2.0,sigma)
        observation1[3] = np.random.normal(mu/2.0,sigma)
        observation1[4] = np.random.normal(mu/2.0,sigma)
        observation1[5] = np.random.normal(mu/2.0,sigma)
        observation1[-2] = 0
        observation1[-1] = 0
        print(f"****   ****   **** Starting New Game ****   ****   ****")
        print(f"Observation 1 {observation1}")
        #
        #game time / transition loop
        while not done_flag:
            #fisrt we choose an action
            action1 = agent_LunarLanderGame101.action_selection(observation1)
            #
            #we enforce that action to get [a new observation , a reward, finish flag state and debug info] from the enviroment
            #observation2, reward2, done_flag, info = lunarEnvironment101.step(action1)
            #observation2, reward2, done_flag, info = lunarEnvironment101.step(action1)
            val = lunarEnvironment101.step(action1)
            observation2, reward2, done_flag, info = np.array(val[0],dtype=np.float32),val[1],val[2],val[3]
            #print(f"Observation 2 {observation2}")
            #
            #we update the score with a reward
            score += reward2
            #
            # we store all the memories from this transition episode
            agent_LunarLanderGame101.store_transition(observation1,action1,reward2,observation2,done_flag)
            #
            # next we try to learn smth from past experiences
            agent_LunarLanderGame101.learn()
            #
            # we set the current state to the new state
            observation1 = observation2
            #
            #val = input()
            #
            #print(f"Descending! {reward2}")
        #lets print some einfo at the end of each episode
        #print(f"{ii} ============================ GAME OVER -> done flag {done_flag}, \nobservation1: {observation1} \nobservation2: {observation2} \nlast reward {reward2}" )
        print(f"============================ GAME OVER -> done flag {done_flag}, \ncounter: {agent_LunarLanderGame101.mem_cntr:.3f} \nobservation2: {observation2} \nlast reward {reward2}" )
        scores.append(score)
        epsides_history.append(agent_LunarLanderGame101.epsilon)
        #
        #lets comute the scores of the last 100 games
        avg_score = np.mean(scores[-avg:])
        print(f"Game:{ii}, avg. score from the last {avg} games:{avg_score:.2f}, final score:{score}, final exploration ration (epsilon): {agent_LunarLanderGame101.epsilon}")
        if avg_score > max_avg_score:
            max_avg_score = avg_score
            message = f"max_avg_score_{avg_score}_mem_counter_{agent_LunarLanderGame101.mem_cntr}"
            agent_LunarLanderGame101.save_state(message)
        if score > max_score:
            max_score = score
            message = f"max_score_{avg_score}_mem_counter_{agent_LunarLanderGame101.mem_cntr}"
            agent_LunarLanderGame101.save_state(message)
    #
    #lets plot some results
    x = [jj+1 for jj in range(n_games)]
    message = f"final_avg_score_{avg_score}_max_score_{max_score}_score_{score}__mem_counter_{agent_LunarLanderGame101.mem_cntr}"
    agent_LunarLanderGame101.save_state(message)
    fileName = f"lunarLander_learning_plot.png"
    env.plot_learning_curve_ap(x,scores,epsides_history,fileName)

if __name__ == "__main__":
    #
    #
    #main_racingCar()
    #
    #
    main_lunarLander()
