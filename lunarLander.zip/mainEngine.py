#python3 mainEngine.py
"""
1.Define Environment 
2.Create an instance object of theEnvironment
3.Define the agent's policy for choosing an action
4.Interact with the environment

    Based on the environment the agent takes a certain action a_t
    Based on this particular action the agent recieve a reward r_t+1

    
5.Update the agents policy based on the n_observations

    Because of the reward r_t, the state of the agent will change, s_t+1

6. Repeat 4 and 5 until the agents policy is satisfied
    
Based on the environment the agent takes a certain action a_t

Based on this particular action the agent recieve a reward r_t+1

Because of the reward r_t, the state of the agent will change, s_t+1


"""

#First the environmet class will give random n_observations, just to check the class implementation

from __future__ import annotations #debugging
#
import numpy as np
#from typing import List
#
import enviroment as env
import torch as T
import pickle
#import system
#
#from enviroment import samepleEnvironment
import gym # environmet class for 
import gymnasium as gymRLenv
#
import seaborn as sn
import tqdm # progress bar
#
from collections import defaultdict # allow acess to keys 
import matplotlib.pyplot as plt
from matplotlib.patches import Patch #for drawing shapes
#

def main_racingCar():


    env101          = env.samepleEnvironment()
    agent101        = env.agent()
    #
    #time loop
    while not env101.is_done():
        agent101.step_episode(env101)
        print("========= End of episode ========= ")
    #
    print(f"Total reward obtained: {agent101.totalReward:.4f}")


def main_lunarLander():
    #
    #
    #Hyperparameter definition
    Gamma           = 0.99#1-1.618#0.99 #update ratio for Q values
    Epsilon         = 1 # this way the agent takes random values at the beggining 
    Batch_size      = 64#1684#64
    Learning_ratio  = 0.0001618#0.0001
    Input_size      = 8 #[8]
    Num_actions     = 4 #do nothing, fire left orientation engine, fire main engine, fire right orientation engine.
    Max_memori_size = 100_000#100*1618#100_000
    Epsilon_end     = 0.01618#0.01
    Epsilon_delta   = 1.618e-4#1.618e-6#5e-4
    avg             = 100 #number of samples to compute average score
    save_ep         = 100 # freq for saving results
    np.random.seed(32)
    mu, sigma = 0.0, 0.1 # mean and standard deviation
    #s = np.random.normal(mu, sigma, size=1000)
    #
    # variable for keepin track of reward scores and episodes
    scores = []
    epsides_history = []
    #
    #lets define for how long does the agent need to learn
    Learning_time   = 500
    n_games = Learning_time*2 #500
    folderName = f"p_201" #parent folder for saving results
    #
    #
    #https://www.gymlibrary.dev/environments/box2d/lunar_lander/
    lunarEnvironment101 = gym.make('LunarLander-v2')
    #lunarEnvironment101 = gym.make(
    #"LunarLander-v2",
    #continuous = False,
    #gravity = -10.0,
    #enable_wind = False,
    #wind_power = 15.0,
    #turbulence_power = 1.5)
    #replayNetwork_LunarLanderGame   = env.LinearDeepQReplayNetwork()
    agent101           = env.agentLunarLander(gamma=Gamma,
                                                           epsilon=Epsilon,
                                                           learningRatio=Learning_ratio,
                                                           input_size=Input_size,
                                                           batch_size=Batch_size,
                                                           num_actions=Num_actions,
                                                           max_memori_size=Max_memori_size,
                                                           epsilon_end=Epsilon_end,
                                                           epsilon_delta=Epsilon_delta)
    #
    #creation of forders for saving results   
    agent101.folder_setup(folderName)
    #
    #Initializing SCORE FOR KEEPING TRACK OF THE BEST PERFORMING MODELS
    max_score       = -100 
    max_avg_score   = -100
    time_policy     = -300
    #
    #episode loop
    for ii in range(n_games):
        # at the top of each new game we set the score, finish flag and observations
        score           = 0
        avg_score       = 0
        done_flag       = False
        #
        #Observing the environment
        resetVal        = lunarEnvironment101.reset()
        #resetVal,info   = lunarEnvironment101.reset()
        #resetVal = list(resetVal)
        #print(resetVal)
        #
        """
        The state is an 8-dimensional vector: the coordinates of the lander in `x` & `y`, its linear
        velocities in `x` & `y`, its angle, its angular velocity, and two booleans
        that represent whether each leg is in contact with the ground or not.
        """
        observation1 = np.zeros(Input_size,dtype=np.float32)
        observation1[0] = np.random.normal(mu,sigma,1)*10
        observation1[1] = np.random.normal(mu,sigma,1)*10
        observation1[2] = np.random.normal(mu,sigma,1)*5
        observation1[3] = np.random.normal(mu,sigma,1)*5
        observation1[4] = np.random.normal(mu,sigma,1)*2
        observation1[5] = np.random.normal(mu,sigma,1)*2
        observation1[-2] = 0
        observation1[-1] = 0
        #print(f"****   ****   **** Starting New Game ****   ****   ****")
        #print(f"Observation 1 {observation1}")
        #
        #game time / transition loop
        while not done_flag:
            #fisrt we choose an action
            action1 = agent101.action_selection(observation1)
            #
            # Interacting with the environment
            #we enforce that action to get [a new observation , a reward, finish flag state and debug info] from the enviroment
            #observation2, reward2, done_flag, info = lunarEnvironment101.step(action1)
            #observation2, reward2, done_flag, info = lunarEnvironment101.step(action1)
            val = lunarEnvironment101.step(action1)
            #
            #Observing the environment
            observation2, reward2, done_flag, info = np.array(val[0],dtype=np.float32),val[1],val[2],val[3]
            """Reward for moving from the top of the screen to the landing pad and coming to rest is about 100-140 points. 
            If the lander moves away from the landing pad, it loses reward. 
            If the lander crashes, it receives an additional -100 points. 
            If it comes to rest, it receives an additional +100 points. 
            Each leg with ground contact is +10 points. 
            Firing the main engine is -0.3 points each frame. 
            Firing the side engine is -0.03 points each frame. 
            Solved is 200 points."""
            #
            #we update the score with a reward
            score += reward2
            #
            # we store all the memories from this transition episode
            agent101.store_transition(observation1,action1,reward2,observation2,done_flag)
            #
            # next we try to learn smth from past experiences
            if ii < Learning_time:
                agent101.learn()
            else:
                action1.Epsilon = 0.0
            #
            # we set the current state to the new state
            observation1 = observation2
            #
            #val = input()
            #
            #print(f"Descending! {reward2}")
        #lets print some einfo at the end of each episode
        print(f"\n============================ GAME OVER episode #{ii},\n\n\tdone flag: {done_flag}, memory counter: {agent101.mem_cntr}, last reward: {reward2:.2f}, \n\n\tobservation2: {observation2}\n" )
        scores.append(score)
        epsides_history.append(agent101.epsilon)
        #
        #lets comute the scores of the last 100 games
        avg_score = np.mean(scores[-avg:])
        #
        #
        print(f"\n\tavg. score from the last {avg} episodes:{avg_score:.2f}/{max_avg_score:.2f},\n\n\tfinal score:{score:.2f}/{max_score:.2f},\n\n\tfinal exploration ratio (epsilon): {agent101.epsilon:.3f}\n\n\n")
        try:
            if avg_score > max_avg_score:
                max_avg_score = avg_score
                print(f"New max average score {max_avg_score:.2f}")
                message = f"ep_{ii}_mem_counter_{agent101.mem_cntr}_max_avg_score_{avg_score:.2f}_eps_{agent101.epsilon:.3f}"
                agent101.save_state(message,agent101.path_max_avg_score)
            if score > max_score:
                print(f"New max score {max_score:.2f}")
                max_score = score
                message = f"ep_{ii}_mem_counter_{agent101.mem_cntr}_max_score_{avg_score:.2f}_eps_{agent101.epsilon:.3f}"
                agent101.save_state(message,agent101.path_max_score)
            if ii%save_ep == 0:
                message = f"ep_{ii}_mem_counter_{agent101.mem_cntr}_freq_{save_ep}_eps_{agent101.epsilon:.3f}"
                agent101.save_state(message,agent101.path_freq)
        except:
            print(f"WARNING! model could no be saved")
        #
        #val = input()
    #
    #lets plot some results
    x = [jj+1 for jj in range(n_games)]
    message = f"final_avg_score_{avg_score}_max_score_{max_score}_score_{score}_mem_counter_{agent101.mem_cntr}_eps_{agent101.epsilon:.3f}"
    agent101.save_state(message,agent101.path_final_score)
    fileName = f"{agent101.path_stats}/lunarLander_learning_plot.png"
    env.plot_learning_curve_ap(x,scores,epsides_history,fileName)


def main_lunarLander_actor_critic_DQN():
    #
    #
    #Hyperparameter definition
    Gamma           = 0.99#1-1.618#0.99 #update ratio for Q values
    Epsilon         = 1 # this way the agent takes random values at the beggining 
    Batch_size      = 64#1684#64
    Learning_ratio  = 0.0001618#0.0001
    Input_size      = 8 #[8]
    Num_actions     = 4 #do nothing, fire left orientation engine, fire main engine, fire right orientation engine.
    Max_memori_size = 100_000#100*1618#100_000
    Epsilon_delta   = 1.618e-4#1.618e-6#5e-4
    Epsilon_end     = 0.01618#0.01
    time_policy     = -0.1 # penalty for time taken to land the spaceCraft
    #lets define for how long does the agent need to learn
    Learning_time   = 800
    n_games         = Learning_time+200+200 #n_games/1.618+(n_games - n_games/1.618)#500
    tau             = 0.05#1/Learning_time #0.005 # Update rate of the target network
    maxSteps        = 5_000
    avg             = 100 #number of samples to compute average score
    save_ep         = 200 # freq for saving results
    #
    np.random.seed(32)
    T.manual_seed(32)
    mu, sigma = 0.0, 0.1 # mean and standard deviation
    #s = np.random.normal(mu, sigma, size=1000)
    #
    # variable for keepin track of number of steps reward scores, and episodes
    n_transition_steps = []
    scores = []
    epsides_history = []
    #
    folderName = f"landerModel" #parent folder for saving results
    #
    #
    #https://www.gymlibrary.dev/environments/box2d/lunar_lander/
    lunarEnvironment101 = gym.make('LunarLander-v2')
    #lunarEnvironment101 = gym.make(
    #"LunarLander-v2",
    #continuous = False,
    #gravity = -10.0,
    #enable_wind = False,
    #wind_power = 15.0,
    #turbulence_power = 1.5)
    #replayNetwork_LunarLanderGame   = env.LinearDeepQReplayNetwork()
    agent101           = env.agentLunarLander(gamma=Gamma,
                                                           epsilon=Epsilon,
                                                           learningRatio=Learning_ratio,
                                                           input_size=Input_size,
                                                           batch_size=Batch_size,
                                                           num_actions=Num_actions,
                                                           max_memori_size=Max_memori_size,
                                                           epsilon_end=Epsilon_end,
                                                           epsilon_delta=Epsilon_delta)
    #
    #creation of forders for saving results   
    agent101.folder_setup(folderName)
    #
    #Initializing SCORE FOR KEEPING TRACK OF THE BEST PERFORMING MODELS
    max_score       = -100 
    max_avg_score   = -100
    #
    #episode loop
    for ii in range(n_games):
        # at the top of each new game we set the score, finish flag and observations
        score           = 0
        avg_score       = 0
        done_flag       = False
        episode_steps   = 0 # for checking the number of transitions done in each episode
        #
        #Observing the environment
        observation1,_        = lunarEnvironment101.reset()
        #resetVal,info   = lunarEnvironment101.reset()
        #resetVal = list(resetVal)
        print(f"\n============================ New Episode #{ii}")
        print(f"\n\n\tInitial State: {observation1}\n")
        #
        """
        The state is an 8-dimensional vector: the coordinates of the lander in `x` & `y`, its linear
        velocities in `x` & `y`, its angle, its angular velocity, and two booleans
        that represent whether each leg is in contact with the ground or not.
        """
        #
        #game time / transition loop
        while not done_flag:
            #fisrt we choose an action
            action1 = agent101.action_selection(observation1)
            #
            # Interacting with the environment
            #we enforce that action to get [a new observation , a reward, finish flag state and debug info] from the enviroment
            #observation2, reward2, done_flag, info = lunarEnvironment101.step(action1)
            #observation2, reward2, done_flag, info = lunarEnvironment101.step(action1)
            val = lunarEnvironment101.step(action1)
            #
            #Observing the environment
            observation2, reward2, done_flag, info = np.array(val[0],dtype=np.float32),val[1],val[2],val[3]
            """Reward for moving from the top of the screen to the landing pad and coming to rest is about 100-140 points. 
            If the lander moves away from the landing pad, it loses reward. 
            If the lander crashes, it receives an additional -100 points. 
            If it comes to rest, it receives an additional +100 points. 
            Each leg with ground contact is +10 points. 
            Firing the main engine is -0.3 points each frame. 
            Firing the side engine is -0.03 points each frame. 
            Solved is 200 points."""
            #
            episode_steps += 1 # updating step counter
            #if episode_steps > maxSteps:
            #    reward2 += -100
            #    done_flag = False
            #    break
            ##
            ##we update the score with a reward based on the time policy
            #score += reward2 + time_policy
            score += reward2 
            #
            # we store all the memories from this transition episode
            #agent101.store_transition(observation1,action1,reward2,observation2,done_flag)
            agent101.store_transition(observation1,action1,reward2,observation2,episode_steps,done_flag)
            #
            # next we try to learn smth from past experiences
            if ii < Learning_time:
                agent101.learn()
                # lets do the soft update of the target network
                target_net_stateDict = agent101.target_net.state_dict()
                policy_net_stateDict = agent101.Q_eval.state_dict()
                #print(agent101.target_net.state_dict())
                #val = input()
                for key in policy_net_stateDict:
                    target_net_stateDict[key] = policy_net_stateDict[key]*tau + target_net_stateDict[key]*(1-tau)
                    #
                agent101.target_net.load_state_dict(target_net_stateDict)
                #val = input()
                #print(agent101.target_net.state_dict())
                #val = input()
                #
            #else:
            #    agent101.epsilon = 0
            #
            #
            # we set the current state to the new state
            observation1 = observation2
            #
            #
            env.pr_bar(episode_steps,maxSteps)
            #
            #
            #print(f"Descending! {reward2}")
        #lets print some einfo at the end of each episode
        print(f"\n============================ End of Episode #{ii},\n\n\tfinal exploration ratio (epsilon): {agent101.epsilon:.3f}, number of transitions: {episode_steps}, memory counter: {agent101.mem_cntr}, last reward: {reward2:.2f}, \n\n\tState:{observation2}\n" )
        n_transition_steps.append(episode_steps)
        scores.append(score)
        epsides_history.append(agent101.epsilon)
        #
        #lets comute the scores of the last 100 games
        avg_score = np.mean(scores[-avg:])
        #
        #
        print(f"\n\tavg. score from the last {avg} episodes:{avg_score:.2f}/{max_avg_score:.2f},\n\n\tfinal score:{score:.2f}/{max_score:.2f}\n\n\n")
        try:
            if avg_score > max_avg_score:
                max_avg_score = avg_score
                print(f"New max average score {max_avg_score:.2f}")
                message = f"ep_{ii}_mem_counter_{agent101.mem_cntr}_max_avg_score_{avg_score:.2f}_eps_{agent101.epsilon:.3f}"
                agent101.save_state(message,agent101.path_max_avg_score)
            if score > max_score:
                print(f"New max score {max_score:.2f}")
                max_score = score
                message = f"ep_{ii}_mem_counter_{agent101.mem_cntr}_max_score_{avg_score:.2f}_eps_{agent101.epsilon:.3f}"
                agent101.save_state(message,agent101.path_max_score)
            if ii%save_ep == 0:
                message = f"ep_{ii}_mem_counter_{agent101.mem_cntr}_freq_{save_ep}_eps_{agent101.epsilon:.3f}"
                agent101.save_state(message,agent101.path_freq)
        except:
            print(f"WARNING! model could no be saved")
        #
        #val = input()
    #
    #lets plot some results
    x = [jj+1 for jj in range(n_games)]
    message = f"final_avg_score_{avg_score}_max_score_{max_score}_score_{score}_mem_counter_{agent101.mem_cntr}_eps_{agent101.epsilon:.3f}"
    agent101.save_state(message,agent101.path_final_score)
    fileName = f"{agent101.path_stats}/lunarLander_learning_plot.png"
    env.plot_learning_curve_ap(x,scores,epsides_history,fileName)
    fileName = f"{agent101.path_stats}/lunarLander_episode_steps_score.png"
    env.plot_learning_curve_totalScore_steps(x,scores,n_transition_steps,fileName)

"""
def main_blackJack():
    print(f"Lets play a blackjack game!")
    env101 = gymRLenv.make('Blackjack-v1',sab=True,render_mode="rgb_array")
    #
    #Observing environment
    done_flag = False
    state101, info101      = env101.reset() #(My card, dealer's car,do I have an ace???) -> (2,7,False)
    #
    #lets select an action101 based on state101
    action101 = env101.action_space.sample()
    #
    #let interact with the environment with action 101 and get a new state102, reward102, finishFlag102, truncationFlag102, info102
    #truncationFlag102 indiates of the state finished earlier due to breaking policy rules  
    #info102 may contain additional info about the environment, such as how many retries are left
    observation102, reward102, finishFlag102, truncationFlag102, info102 = env101.step()
    #
    #
    class agent_blackjack:
        def __init__ (self,
                      learning_rate:float,
                      inital_epsilon:float,
                      epsilon_end:float,
                      epsilon_decay:float,
                      discount_factor:float = 0.95
                      ):
            #Initializing agent with an empty dictionary of state-action values (q_values), learning rate and epsilon
            self.q_values = defaultdict(lambda:np.zeros(env101.action_space.n))
            #
            self.lr             = learning_rate
            self.gamma          = discount_factor
            self.epsilon        = inital_epsilon
            self.epsilon_end    = epsilon_end
            self.eps_delta      = epsilon_decay
            self.training_error = []
        #
        #
        def get_action(self,observation1:tuple[int,int,bool] )->int:
            if np.random.random()  < self.epsilon:
                return env101.action_sample.sample()
            else:
                return int(np.argmax(self.q_values[observation1]) )
        #
        #
        def update(self,
                   observation1:tuple[int,int,bool],
                   action:int,
                   reward:float,
                   terminated:bool,
                   observation2:tuple[int,int,bool]
                   ):
            #updates the q-value of actionsº
            future_q_value = (not terminated) * np.max(self.q_values[observation2])
            #
            # let evaluate the loss function
            temporal_difference = (
                reward + self.discount_factor * future_q_value - self.q_values[observation1][action]
            )
            #
            self.q_values[observation1][action] = self.q_values[observation1][action] + self.lr*temporal_difference
            self.training_error.append(temporal_difference)
        #
        #
        def deacy_epsilon(self):
            self.epsilon = max(self.epsilon-self.eps_delta,self.epsilon_end) 
        #
    #
    learning_rate       = 0.01
    n_epsiodes          = 100_000
    start_epsilon       = 1.0
    epsilon_decay       = start_epsilon / (n_epsiodes/2)
    epsilon_end         = 0.1
    discount_factor     = 0.95
    #
    agent101 = agent_blackjack(learning_rate,
                               start_epsilon,
                               epsilon_end,
                               epsilon_decay,
                               discount_factor
                               )
    from IPython.display import clear_output
    #env101 = gym.wrapper.RecordEpsisodeStatistics(gymRLenv.deque_size=n_epsiodes)
    env101 = gym.wrappers.RecordEpisodeStatistics(env101.deque_size=n_epsiodes)
    #
    #episode loop
    for episode in tqdm(range(n_epsiodes)):
        obs, info = env101.reset()
        done_flag = False
        clear_output()
        #
        # transition loop
        while not done_flag:
            action = agent101.get_action(obs)
            next_obs, reward102, terminated,truncated,info() = env.step(action)
            agent101.update(obs,reward102, terminated,next_obs)
            #
            #graphic display
            frame = env.render()
            plt.imshow(frame)
            plt.show()
            #
            obs = next_obs
            done_flag = terminated or truncated
            #
        #
        agent101.deacy_epsilon()
"""
#
#
#
def main_carPole():
    #https://www.youtube.com/@freecodecamp/playlists
    #
    #packages
    #!pip install gymnasium[classic_control]
    import gymnasium as gym101
    import math
    import random
    import matplotlib
    import matplotlib.pyplot as plt
    from collections import namedtuple, deque
    from itertools import count
    #
    import torch as T
    import torch.nn as nn
    import torch.optim as optim
    import torch.functional as functional
    #
    env101 = gym101.make("CartPole-v1")
    #
    #checking display setup
    is_ipython = 'inline' in matplotlib.get_backend
    if is_ipython :
        from IPython import display
    plt.ion()
    #
    # selecting device
    device_name = "cuda" if T.cuda.is_available() else "cpu"
    device = T.device()
    #
    #
    Transition = namedtuple('Transition',
                                ('state',
                                 'action',
                                 'next_state',
                                 'reward') )
    #
    class ReplayMemory(object):
        # creation of memroy (aka replay buffer) to store past experiences  and create randonm samples to use as a bath to learn using
        # a method from the agent (dqn) class
        def __init__(self,capacity):
            self.memory = deque([],maxlen=capacity)
        #
        def push(self,*args):
            #saving transition
            self.memory.append(Transition(*args))
        #
        def sample(self,batch_size):
            # creating batch from random samples of memory states, acctions, rewards, ...
            return random.sample(self.memory,batch_size)
        #
        def __len__(self):
            #checking memory size
            return len(self.memory)
    #
    #
    class dqn(nn.Module):
        # Initializes Q-network with random weights
        #
        # convergence loop
        #    samples an action using a epsilon-greedy policy
        #      selects an action with the highest Q value with a frequency of (1-epsilon)% of the time
        #      selects a  random action with a frequency of epsilon% of the time
        #    executes an action
        #    gets the nexts state from the environment
        #    Calls an external mentod to store the transition (state,action,reward,next_state) in the replay buffer
        #    Calls an external method to get a batch from the replay buffer
        #   
        #    Computes the Q_target value for the minibatch using Bellman equation: Q_t = reward + gamma*max( Q_(next_state,action) )
        #    Computes Q_values for the minibatch using the Q-Network: Q_values = Q(state,action)
        #    Computes the loss from Q_target and Q_values 
        #
        # The target network is a copy of the Q-network with weights updated less frequently, this helps to prevent 
        # the Q-values from osciallating
        #
        # The model is a convolutional network that takes in the difference between the current and previous screen patches
        # It has to Outputs : Q(s,left) and Q(s,right). The model tries to predict the expected return of taking each action
        # given the current input
        #
        def __init__(self,n_observations,n_actions,nL1=128,nL2=128):
                    super().__init__()
                    # super(dqn,self).__init__()
                    self.layer1 = nn.Linear(n_observations,nL1)
                    self.layer2 = nn.Linear(nL1,nL2)
                    self.layer3 = nn.Linear(nL2,n_actions)
        #
        def forward(self,x):
            x = F.relu(self.layer1(x))
            x = F.relu(self.layer2(x))
            return F.relu(self.layer3(x))
        #
        #
    #
    """
    During training the Q-Network is updated using the Bellman ecuation to minimize the mean-squared error
    between the predicted Q-value and the target values of Q-target. The target values are computed using 
    the Q-Network (dqn) but with the weightsfronzen and not updated during the current training iteration.
    This helps to stabilize the training process and prevent the network form overfitting the training data. 
    """
    #
    # Number of transitions samples from the replay buffer
    batch_size      = 128 #64
    # Discount factor from Bellman equation
    gamma           = 0.99 
    epsilon_start   = 0.9 #1 # initial value
    epsilon_end     = 0.05 #0.01#0.01618
    epsilon_decay   = 1000
    tau             = 0.005 # Update rate of the target network
    lr              = 1e-4 #learning rate
    memory_capacity = 10000
    #
    # Lets get the number of actions from the environment object 
    n_actions = env101.action_space.n
    #
    # Lets get the number of state observations
    state,info = env101.reset()
    #
    # checkin the number of observations / number of state feaures used to learn
    n_observations = len(state)
    print(f"The envrionment provides {n_observations} parameters")
    #
    # lets instantiate the Q-network (actor agent) for  action selection, that will learn based on a certain policy 
    # defined by the environment
    policy_net = dqn(n_observations= n_observations,
                     n_actions= n_actions
                     ).to(device)
    #
    # lets define the target network (critic agent) for the replying strategy
    target_net = dqn(n_observations= n_observations,
                     n_actions= n_actions
                     ).to(device)
    # at the beginning lets make that the traget network has the same weights than the Q-network
    target_net.load_state_dict(policy_net.state_dict() )
    #
    # lot define the optimizer for the target network
    optimizer = optim.AdamW(policy_net.parameters(),lr = lr, amsgrad = True)
    """
    Adam optimizer (Adaptive Moment Estimation) is an improved varsion of Stochastic Gradient Descent (SGD).
    It combines advantages from AdaGrad and RMSProp

    In parcular we use AdamW that incoporates weight decay regularzation for the first and second moment  of the 
    loss function gradients. This helps to prevent overffiting by adding a penalty to the loss function that is 
    proportional to the magnitude of the weights. I a way, this penalty encourages the network to learn simple and
    general representations
    """
    #
    # lets instantiate the memory object
    memory101 = ReplayMemory(memory_capacity)
    #
    #lets initilize the number of transition steps
    steps_done = 0
    #
    def select_action(state):
        #    select_action will select an action acoring to an epsilon greedy policy
        global steps_done
        sample = random.random()
        eps_threshold = epsilon_end + (epsilon_start-epsilon_end)*math.epx(-1.0*steps_done/epsilon_decay)
        steps_done += 1
        if sample > eps_threshold:
            with T.no_grad(): # we will select a random action, so with turn of the gradient calculation
                #t.max(1) will return the largest column value
                #[1] second column on max result where it was foun
                return policy_net(state).max(1)[1].view(1,1)
        else:
            return policy_net( [ [env101.action_space_sample()] ],dtype=T.long )
        #
    #
    # leys instatiate variables for keepin track of statistis
    episode_duration = []
    #
    #
    def plot_duration(show_result=False):
        #    plot_durations plots the duration of the episodes along with an average of the last 100 episodes.
        plt.figure(1)
        duration_t = T.tensor(episode_duration,dtype=T.float)
        if show_result:
            plt.title('Result')
        else:
            plt.cfl()
            plt.title('Training')
            plt.xlabel('Episodes')
            plt.xlabel('Durantion')
            plt.plot(duration_t.numpy())
        #
        # computing moving average
        if (len(duration_t) >= 100): #compute average
            means = duration_t.unfold(0,1000,1).mean(1).view(-1) #check123
            means = T.cat((T.zeros(99),means))
            plt.plot(means.numpy())
        #
        #time pause to update plots 
        plt.pause(0.001)
        if is_ipython:
            if not show_result:
                display.display(plt.gfc())
                display.clear_output(wait=True)
            else:
                display.display(plt.gfc())
            #
        #
    #
    #
    # lets create an optimizer method
    def optimizer_mode():
        if len(memory101) < batch_size:
            return # we do nothing because the memory does not have enough info
        #
        # lets extract a mini-natch of transitions(state,action,reward,next_state) fro the replay memory
        transition101 = memory101.sample(batch_size)
        #
        # lets convert a batch-array transition to a transition of batc arrays
        batch101 = Transition(*zip(*transition101))
        #
        #compute a maks of non-final states  and concatenate the batch elements
        no_final_mask = T.tensor(tuple(map(lambda s: s is not None,batch101.next_state)), device=device,dtype=np.bool) #check123
        #
        non_final_next_states = T.cat([s for s in batch101.next_state if s is not None])
        #
        state_batch = T.cat(batch101.state)
        action_batch = T.cat(batch101.action)
        reward_batch = T.cat(batch101.n_observations)
        #
        # lets get some initial stimation of the actions to take
        sate_action_values = policy_net(state_batch).gather(1,action_batch)
        #
        # lets compute some Q values
        next_state_values = T.zeros(batch_size,device=device)
        with T.no_grad():
            next_state_values[no_final_mask] = target_net(non_final_next_states).max(1)[0]
        #
        # lets compute the expected Q value for each transtiotion using the target network
        expected_state_action_values = next_state_values * gamma + reward_batch
        #
        #
        # les comute the Huber loss (smooth aproximation of the mean-squared)
        # It is less sensitive to outliers than torch.nn.MSELoss and in some cases prevents exploding gradients
        criterion = nn.SmoothL1Loss()
        loss = criterion(expected_state_action_values , expected_state_action_values.unsqueeze(1)) #check123
        #
        #
        # lets optimize the model
        optimizer.zero_grad()
        loss.backward()
        #
        # In-place gradient clipping
        max_value = 100 # To prevent exploding gradients
        T.nn.utils.clip_grad_value(policy_net.parameters(),max_value)#check123
        """ https://saturncloud.io/blog/how-to-do-gradient-clipping-in-pytorch/
        During training, we use the clip_grad_norm_ function to clip the gradients of the neural network parameters to 
        a maximum norm of 1.0. This ensures that the gradients are scaled down to a reasonable size, preventing exploding 
        gradients.

        Choosing the Maximum Gradient Norm Value
        The maximum gradient norm value that you use for gradient clipping depends on the specific model and dataset that 
        you’re working with. In general, you should choose a value that is large enough to allow the model to learn quickly, 
        but small enough to prevent exploding gradients.

        A good starting point for the maximum gradient norm value is 1.0, as shown in the example above. You can experiment 
        with different values to see what works best for your model and dataset.
        """
        # lets update the weights of the policy network
        optimizer.step()
        #
    #
    #
    if T.cuda.is_available():
        num_episodes = 600
    else:
        num_episodes = 500
    #
    for ii_episode in range(num_episodes): #episode loop
        # lets initialize the environmet
        state, info = env101.reset()
        # lets transform the state to a sutable format for the policy and target networks
        state = T.tensor(state,dtype=T.float32,device = device).unsqueeze(0) #https://pytorch.org/docs/stable/generated/torch.unsqueeze.html#torch.unsqueeze
        #
        for tt in count():
            action = select_action(state)
            n_observation1, reward, terminated, truncated, _ = env101.step(action.item())
            reward = T.tensor([reward],device=device)
            done_flag = terminated or truncated
            if terminated:
                next_state = None
            else:
                next_state = T.tensor(n_observation1,dtype=T.float32,device=device).unsqueeze(0)
            #
            # lets add this step to the memory banks
            memory101.push(state,action,next_state,reward)
            #
            # lets move to the next state
            state = next_state
            #
            # lets optimize the policy network model
            optimizer_mode()
            #
            # lets do the soft update of the target network
            target_net_stateDict = target_net.state_dict()
            policy_net_stateDict = target_net.state_dict()
            for key in policy_net_stateDict:
                target_net_stateDict[key] = policy_net_stateDict[key]*tau + target_net_stateDict[key]*(1-tau)
            #
            #
            if done_flag:
                episode_duration.append(tt+1)
                plot_duration
                break
            #
        #
        print(f"Episode #{ii_episode} complete ======")
        plot_duration(show_result=True)
        plt.ioff()
        plt.show()
#
#
#
if __name__ == "__main__":
    #
    #
    #main_racingCar()
    #main_lunarLander()
    main_lunarLander_actor_critic_DQN()
    #
    #
    #main_carPole()
    #main_blackJack()
